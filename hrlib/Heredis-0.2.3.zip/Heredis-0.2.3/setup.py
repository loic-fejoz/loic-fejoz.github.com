#!/usr/bin/env python

from distutils.core import setup

setup(name="Heredis",
      version="0.2.3",
      description="Utilities to read Heredis File (.hr5 and some .hr7)",
      author="Loic Fejoz",
      author_email="loic@fejoz.net",
      url="http://yermat.net1.nerim.net/Ressources/HeredisLib",
      packages=['Heredis'],
     )


#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Individu
import Buffer

signature = {0:u'Signe peut-etre',
             1:u'Sait signer',
             2:u'Ne signe pas'}

enfant = {0:u'enfant legitime',
          1:u'enfant naturel',
          2:u'enfant reconnu',
          3:u'enfant legitime',
          4:u'enfant trouve',
          5:u'enfant adopte',
          6:u'enfant adulterin',
          7:u'enfant mort-ne',
          8:u'filiation non connue'}

class IndividuCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Individu.Individu(offset = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.fatherID,result.motherID) = b.get('<II')
        (result.surnameID,) = b.get('<I')
        (result.unknown3,) = b.get('<I')
        if result.unknown3:
            print 'unknown3',result.unknown3
        result.name = b.getString()
        result.activity = b.getString()
        result.sex = b.getString()
        result.note = b.getString()
        result.numero = b.getString()
        #10 user-specific fields
        result.champs = [''] * 10
        for x in range(10):
            result.champs[x] = b.getString()
        (result.unknown4,) = b.get('<I')
        (result.sansDesc,) = b.get('<B')
        (result.signatureId,) = b.get('<B')
        try:
            result.signature = signature[result.signatureId]
        except KeyError:
            result.signature = str(result.signatureId)
        #enfant...
        (result.enfantId,) = b.get('<B')
        try:
            result.enfant = enfant[result.enfantId]
        except KeyError:
            result.enfant = str(result.enfantId)
        (result.marque,) = b.get('<B')
        (result.unknown5,) = b.get('<H')
        (result.confidentiel,) = b.get('<B')
        result.suffixe = b.getString()
        result.surnom = b.getString()
        result.titre = b.getString()
        #unknown
        # do not know what means what remain...
        result.reste = b.remain()
        return result


    #>------------------------------------------------------------------------
    def encode(self, indi):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',int(indi.id))
        b.addDummy(format = '<II')
        b.set('<I',int(indi.fatherID))
        b.set('<I',int(indi.motherID))
        b.set('<I',int(indi.surnameID))
        b.addDummy(format='<I')
        b.setString(indi.name)
        b.setString(indi.activity)
        b.setString(indi.sex)
        b.setString(indi.note)
        b.setString(indi.numero)
        #10 user-specific fields
        for x in range(10):
            b.setString(indi.champs[x])
        b.addDummy(format='<I')
        b.set('<B',int(indi.sansDesc))
        b.set('<B',int(indi.signatureId))
        #enfant...
        b.set('<B',int(indi.enfantId))
        b.set('<B',int(indi.marque))
        b.addDummy(format='<H')
        b.set('<B',int(indi.confidentiel))
        b.setString(indi.suffixe)
        b.setString(indi.surnom)
        b.setString(indi.titre)
        b.addRaw('\x00')
        return b.buffer

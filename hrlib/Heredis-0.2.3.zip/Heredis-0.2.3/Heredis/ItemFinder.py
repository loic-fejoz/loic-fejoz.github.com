#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


class ItemFinder:

    def getItemAtPos(self,table, offset, size):
        pos = table.getPos() + offset
        file =  table.getFile()
        file.seek(pos)
        buffer = file.read(size)
        decoder = table.getItemDecoder()
        return decoder.decode(buffer)
        

    #>------------------------------------------------------------------------
    def getItemAtIndex(self, table, index, sizeTable=None, idTable=None):
        """
        (TODO : add description)
        index begin at 1

        @param Table table
        @param Int index
        @param Table sizeTable
        @param Table idTable
        @return Item
        @since 1.0
        @author 
        """
        pass
            
                


    #>------------------------------------------------------------------------
    def getItemById(self, table, id, sizeTable=None, idTable=None):
        """
        (TODO : add description)

        @param Table table
        @return Item
        @since 1.0
        @author 
        """
        if idTable:
            item =  self.dichotomicSearch(idTable,id)
            #item =  self.simpleSearch(idTable,id)
            return table.getItemAtIndex(item.getIndex())
        else:
            return self.simpleSearch(table,id)

        
    def simpleSearch(self,table,id):
        """ return the item with id """
        for item in table:
            if item.getId() == id:
                return item
        raise KeyError(id)

    def dichotomicSearch(self,table,id):
        """ return the item with id """
        #recherche par Dichotomie
        debut = 1
        fin = table.getHeader().getLength()
        while debut<= fin:
            milieu = (debut + fin) / 2
            item = table.getItemAtIndex(milieu)
            ID = item.getId()
            if ID == id:
                return item
            else:
                if id < ID:
                    fin = milieu - 1
                else:
                    debut = milieu + 1
        raise KeyError(id)



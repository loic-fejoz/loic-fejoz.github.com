#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class LinkDoc(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'evtID=',self.evtID
        print 'sourceID=',self.sourceID
        print 'note=',self.note

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Item
class OffsetItem(Item.Item):


    #>------------------------------------------------------------------------
    def __init__(self, offsetInFile=None, index=None, offset=None):
        """
        (TODO : add description)

        @param Int id
        @param Int offsetInFile
        @param Int offset
        @since 1.0
        @author 
        """
        Item.Item.__init__(self,offsetInFile,index)
        self._offset = offset


    #>------------------------------------------------------------------------
    def getOffset(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._offset

    def setOffset(self,offset):
        self._offset = offset



#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class LinkMedia(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'ownerID=',self.ownerID
        print 'mediaID=',self.mediaID
        print 'mainMedia',self.mainMedia


    # media
    def getMedia(self):
        if self.heredisFile and self.mediaID:
            return self.heredisFile.getTable('TH5TableMedias').getItemById(self.mediaID)

    def setMedia(self,media):
        self.mediaID = media.id

    media = property(getMedia,setMedia)

    # owner
    def getOwner(self):
        if self.heredisFile and self.ownerID:
            return self.heredisFile.getItemById(self.ownerID)

    def setOwner(self,Owner):
        self.ownerID = owner.id

    owner = property(getOwner,setOwner)

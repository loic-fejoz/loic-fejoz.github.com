import ItemEncoder
import ItemDecoder
import Buffer
import Sosa
import Misc

class SosaCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Sosa.Sosa(offsetInFile = offsetInFile,id = theId)
        result.indiId = theId
        #this part should be review...
        #seems strange so much of blank... ;-)
        b.skip(28)
        (result.sosa,) = b.get('>I')
        return result

    #>------------------------------------------------------------------------
    def encode(self, sosa):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',sosa.getId())
        b.addDummy(b=28)
        b.set('>I',sosa.sosa)
        return b.buffer

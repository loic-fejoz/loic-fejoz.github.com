#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class Place(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'mainId=',self.mainID
        print self.town
        print self.code
        print self.department
        print self.region
        print self.country

    def cmp(self,other):
        return cmp(self.otwn,other.town)

    # mainPlace
    def getMainPlace(self):
        if self.mainID == self.id:
            return self
        if self.heredisFile and self.mainID:
            return self.heredisFile.getTable('TH5TableDicoLieux').getItemById(self.mainID)

    def setMainPlace(self,place):
        self.mainID = place.id

    mainPlace = property(getMainPlace,setMainPlace)

    def __str__(self):
        return "%s,%s,%s,%s,%s" % (self.town,self.code,self.department,self.region,self.country)

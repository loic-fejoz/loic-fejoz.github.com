#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import struct
import Misc
import Buffer


class TableHeader:
    
    #>------------------------------------------------------------------------
    def __init__(self,tableName = None):
        """
        (TODO : add description)

        @since 1.0
        @author 
        """
        self._itemSize = 0					#Int
        self._length = 0					#Int
        self._tableSize = 0					#Int
        self._name = tableName					#String
        self._offset = 0					#Int
        self._fixedSize = False                                 #Boolean


    #>------------------------------------------------------------------------
    def getOffset(self):
        """
        (TODO : add description)

        @return In
        @since 1.0
        @author 
        """
        return self._offset


    #>------------------------------------------------------------------------
    def getLength(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._length

    def setLength(self,length):
        self._length = length
    
    #>------------------------------------------------------------------------
    def getTableSize(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return  self._tableSize

    def setTableSize(self,size):
        self._tableSize = size

    #>------------------------------------------------------------------------
    def writeTo(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.addRaw('\xC0\xDE\xCA\xFE')
        b.set('<40s',self._name)
        b.setString(str(self._itemSize).zfill(12-1))
        b.setString(str(self._length).zfill(12-1))
        b.setString(str(self._tableSize).zfill(12-1))
        file.write(b.buffer)


    #>------------------------------------------------------------------------
    def readFrom(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        self._offset = file.tell()
        buffer = file.read(80)
        (code,name,itemSize,nbItem,tableSize) = struct.unpack("<4s40s12s12s12s",buffer)
        if code != '\xC0\xDE\xCA\xFE':
            #print Misc.str2hex(code)
            raise ValueError
        self._name = Misc.cString2String(name)
        self._itemSize = int(itemSize[:-1])
        self._length = int(nbItem[:-1])
        self._tableSize = int(tableSize[:-1])
        self._fixedSize = ((self._itemSize * self._length) == self._tableSize)
        file.seek(self._tableSize,1)


     #>------------------------------------------------------------------------
    def isFixedSize(self):   
        return self._fixedSize


    #>------------------------------------------------------------------------
    def getTableName(self):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        return self._name

    #>------------------------------------------------------------------------
    def setTableName(self,tableName):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        self._name = tableName


    #>------------------------------------------------------------------------
    def getItemSize(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return  self._itemSize

    def getSize(self):
        return 80

    def dump(self):
        print self._name, self._itemSize,self._length,self._tableSize,self._fixedSize

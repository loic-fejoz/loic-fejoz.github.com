#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder

class IdIndexCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        (id,index) =  struct.unpack("<II",buffer)
        result = IdIndex.IdIndex(offsetInFile,id,index)
        return result


    #>------------------------------------------------------------------------
    def encode(self, item):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        result = struct.pack("<II",item.getId(),item.getIndex())
        return result

def test():
    codec = IdIndexCodec()
    ch  = '\n\x00\x00\x00\x14\x00\x00\x00'
    print Misc.str2hex(ch)
    t1 = codec.encode(codec.decode(ch))
    print Misc.str2hex(t1)
    print  ch == t1
    tmp = IdIndex.IdIndex(None,10,20)
    print  tmp
    t2 = codec.decode(codec.encode(tmp))
    print t2
    print tmp == t2

if __name__ == '__main__':
    test()



#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


class ItemEncoder:


    #>------------------------------------------------------------------------
    def encode(self, item):
        """
        (TODO : add description)

        @param Item item
        @return buffer
        @since 1.0
        @author 
        """
        pass



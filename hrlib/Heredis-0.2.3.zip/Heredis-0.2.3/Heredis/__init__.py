# -*- coding: iso-8859-1 -*-
import HeredisFile
import TableFabric
import ItemFinderFabric
import ItemDecoderFabric
import ItemEncoderFabric
import OptimizerFabric

def openHeredisFile(filename):
    fabric = TableFabric.TableFabric()
    fabric.setItemFinderFabric(ItemFinderFabric.ItemFinderFabric())
    fabric.setItemDecoderFabric(ItemDecoderFabric.ItemDecoderFabric())
    fabric.setItemEncoderFabric(ItemEncoderFabric.ItemEncoderFabric())
    fabric.setOptimizerFabric(OptimizerFabric.OptimizerFabric())
    return HeredisFile.HeredisFile(fabric,filename = filename)

def getByIndex(hFile,tableName,index):
    t = hFile.getTable(tableName)
    return t.getItemAtIndex(index)

def test():
    hFile = openHeredisFile('fejoz.hr5')
    #print getByIndex(hFile,"TH5TableDicoLieux-IDList",1)
    #print getByIndex(hFile,"TH5TableEvenements-ItemSize",1)
##    t = hFile.getTable("TH5TableIndividus")
##    for i in range(1,8):
##        elt = t.getItem(index=i)
##        print i,elt
##        elt.dump()
    #print t.getItem(id=26)
    #print t.getItem(id=176)
##    for indi in t:
##        print indi
    #print getByIndex(hFile,"TH5TableDicoNoms",2)
    #getByIndex(hFile,"TH5TableEvenements",50).dump()
##    for t in hFile.getTables():
##        print '-------------------------------',t.getName(),'-----------------'
##        for i in range(1,3):
##            print t.getItemAtIndex(i)
    hFile.close()

if __name__=='__main__':
    test()

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


class Item(object):

    def __init__(self,offsetInFile=None,id=None):
        self._offsetInFile = offsetInFile     #int
        self._id = id         #
        self.heredisFile = None

    #>------------------------------------------------------------------------
    def getOffsetInFile(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._offsetInFile


    #>------------------------------------------------------------------------
    def setId(self, id):
        """
        (TODO : add description)

        @param Int id
        @since 1.0
        @author 
        """
        self._id = id


    #>------------------------------------------------------------------------
    def setOffsetInFile(self, offset):
        """
        (TODO : add description)

        @param Int offset
        @since 1.0
        @author 
        """
        self._offsetInFile = offset


    #>------------------------------------------------------------------------
    def getId(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._id

    id = property(getId,setId,doc='Internal Identifier for an item')

    def __cmp__(self,other):
        return 0

##    def __str__(self):
##        return '<'+str(self.__class__)+'(@'+str(self._id)+')>'

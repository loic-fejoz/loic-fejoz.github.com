#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import IdIndexCodec
import OffsetItemCodec
import IndividuCodec
import NameCodec
import EvenementCodec
import AdressCodec
import PlaceCodec
import LinkCodec
import LinkDocCodec
import LinkMediaCodec
import MediaCodec
import SosaCodec
import SourceCodec
import UnionCodec
import IdxDocCodec
import QuickListCodec
import QuickListChildCodec
import TBUnionIdxCodec
import TBEventIdxCodec

import RawItemCodec

class ItemEncoderFabric:

    def __init__(self):
        self._id = IdIndexCodec.IdIndexCodec()
        self._size = OffsetItemCodec.OffsetItemCodec()

    #>------------------------------------------------------------------------
    def getItemEncoder(self, tableHeader):
        """
        (TODO : add description)

        @param String tableName
        @return ItemEncoder
        @since 1.0
        @author 
        """
        tableName = tableHeader.getTableName()
        if tableName[-6:] == "IDList":
            return self._id
        elif tableName[-8:] == "ItemSize":
            return self._size
        elif tableName == "TH5TableIndividus":
            return IndividuCodec.IndividuCodec()
        elif tableName == "TH5TableDicoNoms":
            return NameCodec.NameCodec()
        elif tableName == "TH5TableEvenements":
            return EvenementCodec.EvenementCodec()
        elif tableName == "TH5TableDicoAdresses":
            return AdressCodec.AdressCodec()
        elif tableName == "TH5TableDicoLieux":
            return PlaceCodec.PlaceCodec()
        elif tableName == "TBLINK":
            return LinkCodec.LinkCodec()
        elif tableName == "TH5LinkDoc":
            return LinkDocCodec.LinkDocCodec()
        elif tableName == "TBMedia-IdxOwner":
            return LinkMediaCodec.LinkMediaCodec()
        elif tableName == "TH5TableMedias":
            return MediaCodec.MediaCodec()
        elif tableName == "SOSATbl":
            return SosaCodec.SosaCodec()
        elif tableName == "TH5Doc":
            return SourceCodec.SourceCodec()
        elif tableName == "TH5TableUnion":
            return UnionCodec.UnionCodec()
        elif tableName == "TBDoc-IdxDoc":
            return IdxDocCodec.IdxDocCodec()
        elif tableName == "QuickList":
            return QuickListCodec.QuickListCodec()
        elif tableName == "QuickList-Childs":
            return QuickListChildCodec.QuickListChildCodec()
        elif tableName == "TBUnion-IdxHusb":
            return TBUnionIdxCodec.TBUnionIdxCodec()
        elif tableName == "TBUnion-IdxSpouse":
            return TBUnionIdxCodec.TBUnionIdxCodec()
        elif tableName == "TBEvent-Idx":
            return TBEventIdxCodec.TBEventIdxCodec()
        else:
            return RawItemCodec.RawItemCodec()



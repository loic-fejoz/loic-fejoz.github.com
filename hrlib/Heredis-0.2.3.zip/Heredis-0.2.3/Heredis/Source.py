#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

from __future__ import generators
import Item

class Source(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'origin=',self.origin
        print 'document=',self.document
        print 'cote=',self.cote
        print 'archivage=',self.archivage
        print 'type=',self.type
        print 'note=',self.note
        print 'name=',self.name
        print 'nature=',self.nature

    def cmp(self,other):
        return cmp(self.name,other.name)

    # LinkMedias
    def getMediasLinks(self):
        if self.heredisFile:
            for linkMedia in self.heredisFile.getTable('TBMedia-IdxOwner'):
                if linkMedia.ownerID == self.id:
                    yield linkMedia

    mediasLinks = property(getMediasLinks,doc="links to medias of this source")

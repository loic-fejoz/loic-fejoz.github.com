#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Buffer
import LinkDoc

class LinkDocCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = LinkDoc.LinkDoc(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.evtID,result.sourceID) = b.get('<II')
        result.note = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, lnk):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',lnk.getId())
        b.addDummy(format='<II')
        b.set('<I',lnk.evtID)
        b.set('<I',lnk.sourceID)
        b.setString(lnk.note)
        b.addRaw('\x00' * 7)
        return b.buffer

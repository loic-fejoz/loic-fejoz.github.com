import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Buffer
import LinkMedia

class LinkMediaCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = LinkMedia.LinkMedia(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.ownerID,result.mediaID) = b.get('<II')
        (result.mainMedia,) = b.get('<I')
        return result

    #>------------------------------------------------------------------------
    def encode(self, lnk):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',lnk.getId())
        b.addDummy(format='<II')
        b.set('<I',lnk.ownerID)
        b.set('<I',lnk.mediaID)
        b.set('<I',lnk.mainMedia)
        b.addRaw('\x00' * 4)
        return b.buffer

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Buffer
import Media

class MediaCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Media.Media(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        result.directory = b.getString()
        result.fileName = b.getString()
        b.skip(format='<B')
        result.comment = b.getString()
        (result.thumbnailLength,) = b.get('<I')
        (result.year1,result.year2) = b.get('<Bb')
        #result.year = result.year2 * 256 + result.year1
        b.skip(format='<HH')
        result.thumbnail = b.remain()
        return result

    #>------------------------------------------------------------------------
    def encode(self, media):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',media.getId())
        b.addDummy(format='<II')
        b.setString(media.directory)
        b.setString(media.fileName)
        b.addRaw('\x01')
        b.setString(media.comment)
        b.set('<I',len(media.thumbnail))
        b.set('<B',media.year1)
        b.set('<b',media.year2)
        b.addDummy(format='<HH')
        b.addRaw(media.thumbnail)
        return b.buffer

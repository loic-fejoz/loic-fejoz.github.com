#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class Link(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'fromID=',self.fromID
        print 'toID=',self.toID
        print 'note=',self.note
        print 'type=',self.typeID,self.type


    # itemFrom
    def getItemFrom(self):
        if self.heredisFile and self.fromID:
            return self.heredisFile.getItemById(self.fromID)

    def setItemFrom(self,itemFrom):
        self.fromID = itemFrom.id

    itemFrom = property(getItemFrom,setItemFrom)

    # itemTo
    def getItemTo(self):
        if self.heredisFile and self.toID:
            return self.heredisFile.getItemById(self.toID)

    def setItemTo(self,to):
        self.toID = to.id

    itemTo = property(getItemTo,setItemTo)

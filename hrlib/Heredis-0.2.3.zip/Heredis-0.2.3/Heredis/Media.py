#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class Media(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print 'directory=',self.directory
        print 'fileName=',self.fileName
        print 'comment=',self.comment
        print 'year=',self.year
        print 'part year 1 =',self.year1
        print 'part year 2 =',self.year2
        print 'thumbail length =',len(self.thumbnail)

    def getYear(self):
        return 256 * self.year2 + self.year1

    def setYear(self,year):
        self.year2 = int(year/256)
        self.year1 = int(year) - self.year2 * 256

    year = property(getYear,setYear,doc="year of the media")

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import ItemFinder

class NotSizedItemFinder(ItemFinder.ItemFinder):


    #>------------------------------------------------------------------------
    def getItemAtIndex(self, table, index, sizeTable=None, idTable=None):
        """
        (TODO : add description)

        @param Table table
        @param Int index
        @param Table sizeTable
        @param Table idTable
        @return String
        @since 1.0
        @author 
        """
        count = table.getHeader().getLength()
        item = sizeTable.getItemAtIndex(index)
        offset = item.getOffset()
        if index + 1 <= count:
            item1 = sizeTable.getItemAtIndex(index+1)
            size = item1.getOffset() - offset
        else:
            size = table.getHeader().getTableSize() - offset
        if not size:
            raise KeyError,index
        return self.getItemAtPos(table,offset,size)



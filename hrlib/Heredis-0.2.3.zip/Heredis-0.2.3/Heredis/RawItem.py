#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item
import Misc

class RawItem(Item.Item):

    def dump(self):
        print self.data
        print Misc.str2hex(self.data)

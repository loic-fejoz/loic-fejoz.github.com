#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Source
import Buffer

nature={0:u'non trouv�',
        1:u'original',
        2:u'copie',
        3:u'photocopie',
        4:u'transcription',
        5:u'numerisation',
        6:u'microfilm',
        7:u'demand�',
        8:u'extrait',
        10:u'introuvable',
        11:u'cdrom',
        12:u'audio',
        16:u'carte',
        17:u'journal',
        13:u'livre',
        14:u'magazine',
        15:u'manuscrit',
        18:u'pierre tombale',
        19:u'video',
        20:u'souvenir',
        21:u'internet'}

class SourceCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Source.Source(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        b.skip(format='<B')
        result.origin = b.getString()
        result.document = b.getString()
        result.cote = b.getString()
        result.archivage = b.getString()
        (result.type,result.unknown3) = b.get('<HH')
        try:
            result.nature = nature[result.type]
        except KeyError:
            result.nature = str(result.type)
        result.note = b.getString()
        result.name = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, source):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',source.getId())
        b.addDummy(format='<II')
        b.addDummy(format='<B')
        b.setString(source.origin)
        b.setString(source.document)
        b.setString(source.cote)
        b.setString(source.archivage)
        b.set('<H',source.type1)
        b.set('<H',source.type2)
        b.setString(source.note)
        b.setString(source.name)
        b.addRaw('\x00' * 2)
        return b.buffer

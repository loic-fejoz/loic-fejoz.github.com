#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import  ItemFinder

class SizedItemFinder(ItemFinder.ItemFinder):


    #>------------------------------------------------------------------------
    def getItemAtIndex(self, table, index, sizeTable=None, idTable=None):
        """
        (TODO : add description)

        @param Table table
        @param Int index
        @param Table sizeTable
        @param Table idTable
        @return String
        @since 1.0
        @author 
        """
        header = table.getHeader()
        itemSize = header.getItemSize()
        offset = itemSize * (index-1)
        return self.getItemAtPos(table,offset,itemSize)

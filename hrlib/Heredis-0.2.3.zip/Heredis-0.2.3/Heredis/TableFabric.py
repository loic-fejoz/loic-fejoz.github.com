#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Table
import CachedTable
import TableHeader

class TableFabric:

    def init(self,finderFabric = None, decoderFabric = None, encoderFabric = None, optimizerFabric=None):
        self._itemFinderFabric = finderFabric               #ItemFinderFabric
        self._itemDecoderFabric = decoderFabric               #ItemDecoderFabric
        self._itemEncoderFabric = encoderFabric               #ItemEncoderFabric
        self._optimizerFabric = optimizerFabric

    def getNullTable(self,tableName):
        h = TableHeader.TableHeader(tableName)
        return self.createTableFromHeader(None,h)

    #>------------------------------------------------------------------------
    def getItemFinder(self, tableHeader):
        """
        (TODO : add description)

        @param String tableName
        @return ItemFinder
        @since 1.0
        @author 
        """
        return self._itemFinderFabric.getItemFinder(tableHeader)


    #>------------------------------------------------------------------------
    def setItemEncoderFabric(self, fabric):
        """
        (TODO : add description)

        @param ItemEncoderFabric fabric
        @since 1.0
        @author 
        """
        self._itemEncoderFabric = fabric

    #>------------------------------------------------------------------------
    def createTable(self, file, pos=None):
        """
        (TODO : add description)

        @param HeredisFile file
        @param Int pos
        @return Table
        @since 1.0
        @author 
        """
        if pos:
            file.seek(pos)
        h = TableHeader.TableHeader()
        h.readFrom(file)
        h.dump()
        return self.createTableFromHeader(file,h)

    def createTableFromHeader(self,file,h):
        t = self.createATable(file,h)
        t.setItemFinder(self.getItemFinder(h))
        t.setItemEncoder(self.getItemEncoder(h))
        t.setItemDecoder(self.getItemDecoder(h))
        t.optimizer = self.getOptimizer(h)
        return t

    def createATable(self,file,header):
        #return Table.Table(file,header)
        return CachedTable.CachedTable(file,header)

    #>------------------------------------------------------------------------
    def setItemDecoderFabric(self, fabric):
        """
        (TODO : add description)

        @param ItemDecoderFabric fabric
        @since 1.0
        @author 
        """
        self._itemDecoderFabric = fabric


    #>------------------------------------------------------------------------
    def setItemFinderFabric(self, fabric):
        """
        (TODO : add description)

        @param ItemFinderFabric fabric
        @since 1.0
        @author 
        """
        self._itemFinderFabric = fabric


    #>------------------------------------------------------------------------
    def getItemDecoder(self, tableHeader):
        """
        (TODO : add description)

        @param String tableName
        @return ItemDecoder
        @since 1.0
        @author 
        """
        return self._itemDecoderFabric.getItemDecoder(tableHeader)


    #>------------------------------------------------------------------------
    def getItemEncoder(self, tableHeader):
        """
        (TODO : add description)

        @param String tableName
        @return ItemEncoder
        @since 1.0
        @author 
        """
        return self._itemEncoderFabric.getItemEncoder(tableHeader)


    def setOptimizerFabric(self,optimizerFabric):
        self._optimizerFabric = optimizerFabric

    def getOptimizer(self,tableHeader):
        if self._optimizerFabric:
            return self._optimizerFabric.getOptimizer(tableHeader)
        else:
            return None

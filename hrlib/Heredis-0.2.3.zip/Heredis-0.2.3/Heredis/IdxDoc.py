#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class IdxDoc(Item.Item):

    def dump(self):
        print 'evtID=',self.evtID
        print 'linkID=',self.linkID
        print 'sourceID=',self.sourceID

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Evenement
import Buffer

evenementType = {4:u'naissance',
                 8:u'bapt�me',
                 12:u'd�c�s',
                 16:u'dipl�me',
                 6:u'inhumation',
                 24:u'acquisition',
                 34:u'adoption',
                 1:u'autre Bapt�me',
                 9:u'bapteme adulte',
                 2:u'bar Mitzvah',
                 3:u'bas Mitzvah',
                 5:u'b�n�diction',
                 10:u'confirmation',
                 35:u'cr�mation',
                 25:u'd�coration',
                 13:u'emigration',
                 26:u'en vie',
                 20:u'homologation de testament',
                 17:u'immigration',
                 18:u'naturalisation',
                 19:u'ordination',
                 32:u'premi�re communion',
                 23:u'profession',
                 7:u'recensement',
                 30:u'r�sidence',
                 21:u'retraite',
                 27:u'service militaire',
                 31:u'testament',
                 33:u'titre',
                 28:"vente d'un bien",
                 29:u'voyage',
                 0:u'bapt�me LDS',
                 11:u'confirmation LDS',
                 14:u'dotation LDS',
                 22:u'liens parental LDS',
                 61:u'union',
                 54:u'divorce',
                 68:u'mariage religieux',
                 55:u'demande de divorce',
                 66:u'adoption',
                 67:u'anulation du mariage',
                 58:u'bans',
                 59:u'contrat de mariage',
                 60:u'certification de publication des bans',
                 64:u'domicile',
                 57:u'�v�nement',
                 15:u'�v�nement',
                 56:u'fian�ailles',
                 65:u's�paration',
                 63:u'lien conjugal LDS'}

class EvenementCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Evenement.Evenement(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.itemID,result.type) = b.get('<IB')
        result.typename = evenementType[result.type]
        (result.placeID,) = b.get('<I')
        (unknown,) = b.get('<B')
        (result.calendar1,result.calendar2) = b.get('<BB')
        (result.modif1,result.modif2) = b.get('<BB')
        (result.day1,result.day2) = b.get('<BB')
        (result.month1,result.month2) = b.get('<BB')
        (result.modif3,) = b.get('<B')
        (result.partYear1,result.selectYear1) = b.get('<BB')
        (result.partYear2,result.selectYear2) = b.get('<BB')
        (result.hour,result.minute) = b.get('<BB')
        b.skip(b=16)
##        b.skip(format='<H')
##        (result.dummy,) = b.get('<H')
##        b.skip(b=11)
        result.note = b.getString()
        result.placeSubdivision = b.getString()
        result.name = b.getString()
        b.skip(format='<H')
        result.ageOnAct = b.getString()
        result.findTheSource = ord(buffer[-3])
        return result

    #>------------------------------------------------------------------------
    def encode(self, event):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',event.getId())
        b.addDummy(format='<II')
        b.set('<I',event.itemID)
        b.set('<B',event.type)
        b.set('<I',event.placeID)
        b.addDummy(format='<B')
        b.set('<B',event.calendar1)
        b.set('<B',event.calendar2)
        b.set('<B',event.modif1)
        b.set('<B',event.modif2)
        b.set('<B',event.day1)
        b.set('<B',event.day2)
        b.set('<B',event.month1)
        b.set('<B',event.month2)
        b.set('<B',event.modif3)
        b.set('<B',event.partYear1)
        b.set('<B',event.selectYear1)
        b.set('<B',event.partYear2)
        b.set('<B',event.selectYear2)
        b.set('<B',event.hour)
        b.set('<B',event.minute)
        b.addDummy(b=15)
##        b.addDummy(format='<H')
##        b.set('<H',257)
##        b.addDummy(b=11)
        b.setString(event.note)
        b.setString(event.placeSubdivision)
        b.setString(event.name)
        b.addDummy(format='<H')
        b.setString(event.ageOnAct)
        b.addRaw('\x00' * 4)
        return b.buffer

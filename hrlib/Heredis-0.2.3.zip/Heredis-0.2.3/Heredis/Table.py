#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import OffsetItem
import IdIndex

class Table:


    #>------------------------------------------------------------------------
    def __init__(self,file,header,optimizer=None):
        """
        (TODO : add description)

        @since 1.0
        @author 
        """
        self._itemFinder = None					#ItemFinder
        self._itemEncoder = None				#ItemEncoder
        self._itemDecoder = None				#ItemDecoder
        self._header = header					#TableHeader
        self._idTable = None					#Table
        self._sizeTable = None					#Table
        self._file = file                                       #HeredisFile
        self._pos = header.getOffset() + header.getSize()
        self._additionnalData = []
        self._originalCount = header.getLength()
        self.sortMe = False
        self.heredisFile = None
        self.optimizer = optimizer

    def loadOptimizer(self):
        """ should be call when all tables are up """
        if self.optimizer:
            self.optimizer.load(self,self.heredisFile)

    def getPos(self):
        """ return the begining of the table's content, ie offset """
        return self._pos

    def getName(self):
        """ return the table's name """
        return self._header.getTableName()


    #>------------------------------------------------------------------------
    def getItemFinder(self):
        """
        (TODO : add description)

        @return ItemFinder
        @since 1.0
        @author 
        """
        return self._itemFinder


    #>------------------------------------------------------------------------
    def setItemDecoder(self, decoder):
        """
        (TODO : add description)

        @param ItemDecoder decoder
        @since 1.0
        @author 
        """
        self._itemDecoder = decoder


    #>------------------------------------------------------------------------
    def setItemEncoder(self, encoder):
        """
        (TODO : add description)

        @param ItemEncoder encoder
        @since 1.0
        @author 
        """
        self._itemEncoder = encoder


    #>------------------------------------------------------------------------
    def getItemById(self, id):
        """
        (TODO : add description)

        @param Int id
        @return Item
        @since 1.0
        @author 
        """
        result =  self._itemFinder.getItemById(self,id,self._sizeTable,self._idTable)
        result.heredisFile = self.heredisFile
        return result
                                             
    #>------------------------------------------------------------------------
    def getItemDecoder(self):
        """
        (TODO : add description)

        @return ItemDecoder
        @since 1.0
        @author 
        """
        return self._itemDecoder


    #>------------------------------------------------------------------------
    def setItemFinder(self, finder):
        """
        (TODO : add description)

        @param ItemFinder finder
        @since 1.0
        @author 
        """
        self._itemFinder = finder


    #>------------------------------------------------------------------------
    def getItemEncoder(self):
        """
        (TODO : add description)

        @return ItemEncoder
        @since 1.0
        @author 
        """
        return self._itemEncoder


    #>------------------------------------------------------------------------
    def setIdTable(self, idTable):
        """
        (TODO : add description)

        @param Table idTable
        @since 1.0
        @author 
        """
        self._idTable = idTable


    #>------------------------------------------------------------------------
    def getItemAtIndex(self, index):
        """
        (TODO : add description)

        @param Int index
        @return Item
        @since 1.0
        @author 
        """
        if index > self._originalCount:
            result = self._additionnalData[index-self._originalCount-1]
        else:
            result = self._itemFinder.getItemAtIndex(self,index,self._sizeTable,self._idTable)
        result.heredisFile = self.heredisFile
        return result


    #>------------------------------------------------------------------------
    def setSizeTable(self, sizeTable):
        """
        (TODO : add description)

        @param Table sizeTable
        @since 1.0
        @author 
        """
        self._sizeTable = sizeTable


    #>------------------------------------------------------------------------
    def getItem(self, id=None, index=None):
        """
        (TODO : add description)

        @param Int id
        @param Int index
        @return Item
        @since 1.0
        @author 
        """
        if id:
            return self.getItemById(id)
        elif index:
            return self.getItemAtIndex(index)
        else:
            return None


    #>------------------------------------------------------------------------
    def writeTo(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        isFixedSize = self._header.isFixedSize()
        itemSize = self._header.getItemSize()
        index = 1
        offset = 0
        size = 0
        l = self
        if self.sortMe:
            l = [x for x in self]
            l.sort()
        for item in l:
            s = self._itemEncoder.encode(item)
            item.data = s
            if self._sizeTable:
                #set correctly the item's size
                i = self._sizeTable.getItemAtIndex(index)
                i.setOffset(offset)
            # take care of the id table to be in growing id...
            if self._idTable:
                #set correctly the item's id
                i = self._idTable.getItemById(item.getId())
                i.setIndex(index)
            length = len(s)
            assert((isFixedSize and length == itemSize) or not isFixedSize)
            offset += length
            size += length
            index += 1
        #set the last one
        if self._sizeTable:
            i = self._sizeTable.getItemAtIndex(index)
            i.setOffset(offset)
            #print i,'offset = %d' % (offset)
        self._header.setTableSize(size)
        assert((isFixedSize and itemSize * (index-1) == size) or not isFixedSize)
        assert(index - 1 == self._header.getLength())
        self._header.writeTo(file)
        for item in l:
            file.write(item.data)


    #>------------------------------------------------------------------------
    def getFile(self):
        """
        (TODO : add description)

        @return HeredisFile
        @since 1.0
        @author 
        """
        return self._file


    #>------------------------------------------------------------------------
    def getHeader(self):
        """
        (TODO : add description)

        @return TableHeader
        @since 1.0
        @author 
        """
        return  self._header


    #>------------------------------------------------------------------------
    def append(self, item):
        """
        (TODO : add description)

        @param Item item
        @since 1.0
        @author 
        """
        self._additionnalData.append(item)
        count = self._header.getLength()
        self._header.setLength(count + 1)
        if self._sizeTable:
            size = self._header.getTableSize()
            offset = OffsetItem.OffsetItem(offset=size)
            self._sizeTable.append(offset)
            #self._header.setTableSize(size + len(item))
        if self._idTable:
            id = IdIndex.IdIndex(id=item.getId(),index = self._originalCount + len(self._additionnalData))
            self._idTable.append(id)

    def __iter__(self):
        return SimpleTableIterator(self)


class SimpleTableIterator:
    """ an iterator for the Table class """
    def __init__(self,table):
        self.table = table
        self.index = 1
        self.count = self.table.getHeader().getLength()

    def __iter__(self):
        return self
    
    def next(self):
        if self.index <= self.count:
            result = self.table.getItemAtIndex(self.index)
            self.index = self.index + 1
            return result
        raise StopIteration

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import IdxDoc
import Buffer

class IdxDocCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        result = IdxDoc.IdxDoc(offsetInFile = offsetInFile)
        (result.evtID,result.sourceID,result.linkID) = b.get('<III')
        return result

    #>------------------------------------------------------------------------
    def encode(self, idx):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',idx.evtID)
        b.set('<I',idx.sourceID)
        b.set('<I',idx.linkID)
        return b.buffer

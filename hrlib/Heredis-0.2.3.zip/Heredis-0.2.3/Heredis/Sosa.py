#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item
import Misc

class Sosa(Item.Item):

    def dump(self):
        print self.sosa,' : ',self.indiId


    # Indi
    def getIndividu(self):
        if self.heredisFile and self.indiID:
            return self.heredisFile.getTable('TH5TableDicoNoms').getItemById(self.indiID)

    def setIndividu(self,indi):
        self.indiID = indi.id

    individu = property(getIndividu,setIndividu)

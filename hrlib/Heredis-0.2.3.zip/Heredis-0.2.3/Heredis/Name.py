#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class Name(Item.Item):

    def __str__(self):
        return '<'+str(self.__class__)+'(@'+str(self._id)+','+str(self.name)+')>'

    def __cmp__(self,other):
        return cmp(self.name,other.name)

    def dump(self):
        print self.name
        print self.mainNameID


    def getMainName(self):
        if self.mainNameID == self.id:
            return self
        if self.heredisFile and self.mainNameID:
            return self.heredisFile.getTable('TH5TableDicoNoms').getItemById(self.mainNameID)

    def setMainName(self,surname):
        self.mainNameID = surname.id

    mainName = property(getMainName,setMainName,doc="principle surname of this variant")

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Table

class CachedTable(Table.Table):

    def __init__(self,file,header):
        Table.Table.__init__(self,file,header)
        self.__indexes = {}
        self.__ids = {}

    #>------------------------------------------------------------------------
    def getItemAtIndex(self, index):
        """
        (TODO : add description)

        @param Int index
        @return Item
        @since 1.0
        @author 
        """
        if index in self.__indexes:
            return self.__indexes[index]
        item = Table.Table.getItemAtIndex(self,index)
        self.__indexes[index] = item
        self.__ids[item.getId()] = item
        return item


    #>------------------------------------------------------------------------
    def getItemById(self, id):
        """
        (TODO : add description)

        @param Int id
        @return Item
        @since 1.0
        @author 
        """
        if id in self.__ids:
            return self.__ids[id]
        item = Table.Table.getItemById(self,id)
        #self.__indexes[index] = item
        self.__ids[item.getId()] = item
        return item



#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import struct
import Misc


class FileHeader(object):


    #>------------------------------------------------------------------------
    def __init__(self):
        """
        (TODO : add description)

        @since 1.0
        @author 
        """
        self._comment = ''					#String
        self._lastId = 0					#Int
        self._name = ''					#String
        self._version = ''					#String
        self._userFields = None					#String[10][2]


    #>------------------------------------------------------------------------
    def getLastId(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._lastId


    #>------------------------------------------------------------------------
    def setName(self, name):
        """
        (TODO : add description)

        @param String name
        @since 1.0
        @author 
        """
        self._name = name




    #>------------------------------------------------------------------------
    def getName(self):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        return self._name


    #>------------------------------------------------------------------------
    def setComment(self, comment):
        """
        (TODO : add description)

        @param String comment
        @since 1.0
        @author 
        """
        self._comment = comment

    #>------------------------------------------------------------------------
    def getComment(self):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        return self._comment

    comment = property(getComment,setComment,doc="comment  about the genealogy in the file")

    #>------------------------------------------------------------------------
    def setLastId(self, lastId):
        """
        (TODO : add description)

        @param Int lastId
        @since 1.0
        @author 
        """
        self._lastId = lastId


    


    #>------------------------------------------------------------------------
    def getVersion(self):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        return self._version

    #>------------------------------------------------------------------------
    def setVersion(self, version):
        """
        (TODO : add description)

        @param String version
        @since 1.0
        @author 
        """
        self._version = version

    #>------------------------------------------------------------------------
    def setUserFields(self, userFields):
        """
        (TODO : add description)

        @param String[10][2] userFields
        @since 1.0
        @author 
        """
        assert len(userFields) == 10
        self._userFields = userFields
        
    #>------------------------------------------------------------------------
    def getUserFields(self):
        """
        (TODO : add description)

        @return String[10][2]
        @since 1.0
        @author 
        """
        return self._userFields

    userFields = property(getUserFields,setUserFields,doc="champs utilsateurs")

    #>------------------------------------------------------------------------
    def writeTo(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        header = '\x00' * 2380
        header = Misc.set('<4s',header,0,'\xC0\xDE\xCA\xFE')
        ch = 'Heredis\x99 5 for Windows\x99\x00'
        format = '<%ds' % len(ch)
        header = Misc.set(format,header,0x8,ch)
        header = Misc.set('<4s',header,0x28,'\x00\x05\xDE\xFA')
        header = Misc.set('<4s',header,0x924,'\x10\x01\x00\x20') #version ?
        header = Misc.set('<32s',header,0x7C,self._name)
        header = Misc.set('<255s',header,0x9C,self._comment)
        header = Misc.set('<32s',header,0x92C,self._version)
        header = Misc.set('<l',header,0x4C,self._lastId)
        index = 0x19C
        for i in range(10):
            (attr,tag) = self._userFields[i]
            header = Misc.set('<32s',header,index,attr)
            header = Misc.set('<32s',header,index+32,tag)
            index += 64
        file.write(header)
        


    #>------------------------------------------------------------------------
    def readFrom(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        header = file.read(2380)
        (code,) = struct.unpack('<4s',header[:4])
        if code != '\xC0\xDE\xCA\xFE':
            print "ceci n'est pas un fichier Heredis valide"
            print Misc.str2hex(code)
            raise ValueError
        (self._name,) = Misc.cString2String(Misc.get('<32s',header,0x7C))
        (self._comment,) = Misc.cString2String(Misc.get('<255s',header,0x9C))
        (self._version,) = Misc.cString2String(Misc.get('<32s',header,0x92C))
        (self._lastId,) = Misc.get('<l',header,0x4C)
        index = 0x19C
        self._userFields = []
        for i  in  range(10):
            (attr,tag) = Misc.cString2String(struct.unpack('<32s32s',header[index:index+64]))
            self._userFields.append((attr,tag))
            index = index + 64
        file.seek(2380)
            

    def dump(self):
        print 'comment: ',self._comment
        print 'lastId: ',self._lastId
        print 'name: ',self._name
        print 'version: ',self._version
        print "user's fields: ", self._userFields


    def getId(self):
        self._lastId += 1
        return self._lastId

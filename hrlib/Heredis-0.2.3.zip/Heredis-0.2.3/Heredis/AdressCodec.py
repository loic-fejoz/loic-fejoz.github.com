#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Adress
import Buffer

class AdressCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Adress.Adress(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.unionID,result.husbandID,result.wifeID) = b.get('<III')
        (result.private,) = b.get('<H')
        b.skip(format='<B')
        result.contact = b.getString()
        result.line1 = b.getString()
        result.line2 = b.getString()
        result.postalCode = b.getString()
        result.town = b.getString()
        result.country = b.getString()
        result.phone = b.getString()
        result.fax = b.getString()
        result.email = b.getString()
        result.web = b.getString()
        result.region = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, address):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',address.getId())
        b.addDummy(format='<II')
        b.set('<I',address.unionID)
        b.set('<I',address.husbandID)
        b.set('<I',address.wifeID)
        b.set('<H',address.private)
        b.addDummy(format='<B')
        b.setString(address.contact)
        b.setString(address.line1)
        b.setString(address.line2)
        b.setString(address.postalCode)
        b.setString(address.town)
        b.setString(address.country)
        b.setString(address.phone)
        b.setString(address.fax)
        b.setString(address.email)
        b.setString(address.web)
        b.setString(address.region)
        b.addRaw('\x00' * 10)
        return b.buffer

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class IdIndex(Item.Item):

    def __init__(self,offset=None,id=None,index=None):
        Item.Item.__init__(self,offset,id)
        self._index = index

    #>------------------------------------------------------------------------
    def getIndex(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return  self._index

    def setIndex(self,index):
        self._index = index

    def __cmp__(self,other):
        return cmp(self._id,other._id)

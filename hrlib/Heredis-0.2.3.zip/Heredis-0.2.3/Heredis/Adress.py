#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import Item

class Adress(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print self.unionID,self.husbandID,self.wifeID
        print 'private=',self.private
        print 'contact=',self.contact
        print self.line1
        print self.line2
        print self.postalCode,self.town
        print self.country
        print 'phone=',self.phone
        print 'fax=',self.fax
        print 'email=',self.email
        print 'web=',self.web
        print 'region=',self.region

    # Husband
    def getHusband(self):
        if self.heredisFile and self.husbandID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(self.husbandID)

    def setHusband(self,husband):
        self.husbandID = husband.id

    husband = property(getHusband,setHusband)

    # Wife
    def getWife(self):
        if self.heredisFile and self.wifeID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(self.wifeID)

    def setWife(self,wife):
        self.wifeID = wife.id

    wife = property(getWife,setWife)

    # Union
    def getUnion(self):
        if self.heredisFile and self.unionID:
            return self.heredisFile.getTable('TH5TableUnion').getItemById(self.unionID)

    def setUnion(self,union):
        self.unionID = union.id

    union = property(getUnion,setUnion)

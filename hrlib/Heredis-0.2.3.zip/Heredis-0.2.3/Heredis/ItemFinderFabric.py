#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import SizedItemFinder
import NotSizedItemFinder

class ItemFinderFabric:

    def __init__(self):
        self._sized = SizedItemFinder.SizedItemFinder()
        self._notSized = NotSizedItemFinder.NotSizedItemFinder()

    #>------------------------------------------------------------------------
    def getItemFinder(self, tableHeader):
        """
        (TODO : add description)

        @param String tabeName
        @return ItemFinder
        @since 1.0
        @author 
        """
        if tableHeader.isFixedSize():
            return self._sized
        else:
            return self._notSized



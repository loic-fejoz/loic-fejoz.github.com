#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import ItemEncoder
import ItemDecoder
import Name
import Buffer

class NameCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Name.Name(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.mainNameID,) = b.get('<I')
        result.name = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, name):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',name.getId())
        b.addDummy(format='<II')
        b.set('<I',name.mainNameID)
        b.setString(name.name)
        b.addRaw('\x00' * 2)
        return b.buffer


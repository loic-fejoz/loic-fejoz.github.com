#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__=''

import ItemEncoder
import ItemDecoder
import OffsetItem
import Misc
import struct

class OffsetItemCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None,index=None):
        """
        (TODO : add description)

        @param String buffer
        @return OffsetItem
        @since 1.0
        @author 
        """
        (offset,) =  struct.unpack("<I",buffer)
        if not index:
            index = offset
        result = OffsetItem.OffsetItem(offsetInFile,index,offset)
        return result


    #>------------------------------------------------------------------------
    def encode(self, item):
        """
        (TODO : add description)

        @param OffsetItem item
        @return String
        @since 1.0
        @author 
        """
        result = struct.pack("<I",item.getOffset())
        return result

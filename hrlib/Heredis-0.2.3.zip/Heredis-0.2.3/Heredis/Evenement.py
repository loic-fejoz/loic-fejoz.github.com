#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

from __future__ import generators
import Item

class Evenement(Item.Item):

    def __str__(self):
        return '<'+str(self.__class__)+'(@'+str(self._id)+','+str(self.typename)+','+str(self.name)+')>'

    def getYear1(self):
        return 256 * self.selectYear1 + self.partYear1

    def getYear2(self):
        return 256 * self.selectYear2 + self.partYear2

    def setYear1(self,year):
        self.selectYear1 = int(year/256)
        self.partYear1 = year - self.selectYear1 * 256

    def setYear2(self,year):
        self.selectYear2 = int(year/256)
        self.partYear2 = year - self.selectYear2 * 256

    year1 = property(getYear1,setYear1,doc="year of the first date")
    year2 = property(getYear2,setYear2,doc="year of the second date")

    def dump(self):
        print self.unknown1,self.unknown2
        print 'id=',self.itemID,'type=',self.type
        print self.typename
        print 'placeID=',self.placeID
        print 'calendar=',self.calendar1,self.calendar2
        print self.modif1,self.modif2
        print 'day=',self.day1,self.day2
        print 'month=',self.month1,self.month2
        print self.modif3
        print self.partYear1,self.selectYear1
        print 'year1=',self.year1
        print self.partYear2,self.selectYear2
        print 'year2=',self.year2
        print self.hour,':',self.minute
        print 'note=',self.note
        print 'place subdivision=',self.placeSubdivision
        print 'name=',self.name
        print 'age on act=',self.ageOnAct
        print 'acet a rechercher ? =',self.findTheSource

    # Place
    def getPlace(self):
        if self.heredisFile and self.placeID:
            return self.heredisFile.getTable('TH5TableDicoLieux').getItemById(self.placeID)

    def setPlace(self,place):
        self.placeID = place.id

    place = property(getPlace,setPlace)


    # Item
    def getItem(self):
        if self.heredisFile and self.placeID:
            return self.heredisFile.getItemById(self.itemID)

    def setItem(self,item):
        self.itemID = item.id

    item = property(getItem,setItem,doc="item that is concern by this event")

    # LinkMedias
    def getMediasLinks(self):
        if self.heredisFile:
            for linkMedia in self.heredisFile.getTable('TBMedia-IdxOwner'):
                if linkMedia.ownerID == self.id:
                    yield linkMedia

    mediasLinks = property(getMediasLinks,doc="links to medias of this event")

    # LinkSources
    def getSourcesLinks(self):
        if self.heredisFile:
            for linkSource in self.heredisFile.getTable('TH5LinkDoc'):
                if linkSource.evtID == self.id:
                    yield linkSource

    sourcesLinks = property(getSourcesLinks,doc="links to sources of this event")



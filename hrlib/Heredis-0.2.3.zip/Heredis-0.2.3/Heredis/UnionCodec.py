#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Union
import Buffer

class UnionCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Union.Union(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.husbandID,result.wifeID) = b.get('<II')
        b.skip(format='<I')
        result.note = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, union):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',union.getId())
        b.addDummy(format='<II')
        b.set('<I',union.husbandID)
        b.set('<I',union.wifeID)
        b.addDummy(format='<I')
        b.setString(union.note)
        b.addRaw('\x00' * 22)
        return b.buffer

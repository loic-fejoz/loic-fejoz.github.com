#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''


import FileHeader
import Misc

class HeredisFile(object):


    #>------------------------------------------------------------------------
    def __init__(self,tableFabric,filename=None,file=None):
        """
        (TODO : add description)

        @since 1.0
        @author 
        """
        self._tables = {}					#{Table}
        self._tablesList = []                                   #[Table]
        self._tableFabric = tableFabric				#TableFabric
        self._header = None					#FileHeader
        self._file = None					#File
        self._lastId = None
        self._recovery = False
        if filename:
            thefile = open(filename,"rb")
        if thefile:
            self._file = thefile
            self.readFrom(thefile)

    def loadOptimizer(self):
        for table in self._tablesList:
            table.loadOptimizer()

    def close(self):
        self._file.close()

    def __del__(self):
        self.close()


    #>------------------------------------------------------------------------
    def getLastId(self):
        """
        (TODO : add description)

        @return Int
        @since 1.0
        @author 
        """
        return self._lastId


    #>------------------------------------------------------------------------
    def getFileHeader(self):
        """
        (TODO : add description)

        @return FileHeader
        @since 1.0
        @author 
        """
        return self._header

    header = property(getFileHeader,doc="header of the file (see FileHeader)")

    #>------------------------------------------------------------------------
    def writeTo(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        self._header.writeTo(file)
        exceptTables = []
        l = [t for t in self._tablesList if t.getName() not in exceptTables]
        for t in l:
            print t.getName()
            t.writeTo(file)


    #>------------------------------------------------------------------------
    def append(self, table):
        """
        (TODO : add description)

        @param Table table
        @since 1.0
        @author 
        """
        self._tables[table.getHeader().getTableName()]=table
        self._tablesList.append(table)


    #>------------------------------------------------------------------------
    def setTableFabric(self, fabric):
        """
        (TODO : add description)

        @param TableFabric fabric
        @since 1.0
        @author 
        """
        self._tableFabric = fabric


    #>------------------------------------------------------------------------
    def getTable(self, tableName):
        """
        (TODO : add description)

        @param String tableName
        @return Table
        @since 1.0
        @author 
        """
        try:
            return self._tables[tableName]
        except KeyError:
            t = self._tableFabric.getNullTable(tableName)
            self.append(t)
            return t


    #>------------------------------------------------------------------------
    def getFile(self):
        """
        (TODO : add description)

        @return File
        @since 1.0
        @author 
        """
        return self._file

    def recoveryAhead(self,file):
        tag = '0000'
        while tag != '\xC0\xDE\xCA\xFE':
            c = file.read(1)
            tag = tag[1:] + c
        print 'seems to find something...'
        file.seek(-4,1)

    def recoveryBack(self,file):
        tag = '0000'
        while tag != '\xC0\xDE\xCA\xFE':
            c = file.read(1)
            tag = c + tag[:-1]
            file.seek(-2,1)
        print 'seems to find something...'
        file.seek(1,1)

    #>------------------------------------------------------------------------
    def readFrom(self, file):
        """
        (TODO : add description)

        @param File file
        @since 1.0
        @author 
        """
        size = Misc.getFileSize(file)
        header = FileHeader.FileHeader()
        header.readFrom(file)
        while file.tell() != size:
            try:
                table = self._tableFabric.createTable(file)
            except ValueError:
                pos = file.tell()
                print 'try backward...'
                self.recoveryBack(file)
                table = self._tableFabric.createTable(file)
                tbn = table.getHeader().getTableName()
                if tbn in self._tables.keys():
                    print 'finally it was ahead'
                    file.seek(pos)
                    self.recoveryAhead(file)
                    table = self._tableFabric.createTable(file)
                self._recovery = True
            self.append(table)
            table.heredisFile = self
            tableName = table.getHeader().getTableName()
            try:
                if tableName == 'TH5LinkMedia-IDList':
                    self.getTable('TBMedia-IdxOwner').setIdTable(table)
                elif tableName[-6:] == "IDList":
                    self.getTable(tableName[:-7]).setIdTable(table)
                elif tableName[-8:] == "ItemSize":
                    self.getTable(tableName[:-9]).setSizeTable(table)
                else:
                    #print "skip : ",tableName
                    pass
            except KeyError,key:
                #print 'KeyError : ',key
                raise
        self._header = header
        print "-----------------------------------"
        print "Il y a %d tables dans ce fichier" % len(self._tables)
        self.loadOptimizer()

    #>------------------------------------------------------------------------
    def getName(self):
        """
        (TODO : add description)

        @return String
        @since 1.0
        @author 
        """
        return str(self._file)

    def getTables(self):
        """Return a list of tables"""
        return self._tables.values()

    def getId(self):
        return self._header.getId()

    def addItem(self,tableName,item):
        self._tables[tableName].append(item)

    def getItemById(self,id):
        for table in self._tablesList:
            try:
                return table.getItemById(id)
            except KeyError:
                pass
        raise KeyError
        

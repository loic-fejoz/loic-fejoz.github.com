#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Buffer
import Link

linkType = {1:u'A�eul(e) -> Descendant(e)',
        2:u'Ami(e) -> Ami(e)',
        3:u'Beau-fr�re/Belle-soeur -> Beau-fr�re/Belle-soeur',
        4:u'Beau-p�re/Belle-m�re -> Gendre/Bru',
        5:u'Lien consanguin',
        6:u'Cousin/Cousine -> Cousin/Cousine',
        7:u'Doublon ? -> Doublon ?',
        8:u'Fr�re/Soeur -> Fr�re/Soeur',
        9:u'Jumeau/Jumelle -> Jumeau/Jumelle',
        10:u'Testateur/Testatrice -> H�ritier/H�riti�re',
        11:u'Oncle/Tante -> Neveu/Ni�ce',
        12:u'Parent(e) -> Parent(e)',
        13:u'A reconnu -> Reconnu par',
        14:u'Tuteur/Tutrice -> Sous tutelle',
        15:u'Autre Lien',
        #16
        17:u'D�clarant',
        18:"Officier d'�tat civil",
        19:u'Officiant Religieux',
        20:u'Parrain/Marraine',
        21:u'Pr�sent(e)',
        22:u'T�moin',
        23:u'Autre Lien'}

class LinkCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Link.Link(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.fromID,result.toID) = b.get('<II')
        result.note = b.getString()
        b.skip(format='<H')
        (result.typeID,) = b.get('<B')
        try:
            result.type = linkType[result.typeID]
        except KeyError:
            result.type =str(result.typeID)
        return result

    #>------------------------------------------------------------------------
    def encode(self, lnk):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',lnk.getId())
        b.addDummy(format='<II')
        b.set('<I',lnk.fromID)
        b.set('<I',lnk.toID)
        b.setString(lnk.note)
        b.addDummy(format='<H')
        b.set('<B',lnk.typeID)
        b.addRaw('\x00' * 2)
        return b.buffer

#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

import Misc
import IdIndex
import struct
import ItemEncoder
import ItemDecoder
import Place
import Buffer

class PlaceCodec(ItemEncoder.ItemEncoder, ItemDecoder.ItemDecoder):


    #>------------------------------------------------------------------------
    def decode(self, buffer,offsetInFile=None):
        """
        (TODO : add description)

        @param String buffer
        @return IdIndex
        @since 1.0
        @author 
        """
        #print buffer
        #print Misc.str2hex(buffer)
        b = Buffer.Buffer(buffer)
        (theId,) = b.get('<I')
        result = Place.Place(offsetInFile = offsetInFile,id = theId)
        (result.unknown1,result.unknown2) = b.get('<II')
        (result.mainID,) = b.get('<I')
        result.town = b.getString()
        result.code = b.getString()
        result.department = b.getString()
        result.region = b.getString()
        result.country = b.getString()
        return result

    #>------------------------------------------------------------------------
    def encode(self, place):
        """
        (TODO : add description)

        @param IdIndex item
        @return String
        @since 1.0
        @author 
        """
        b = Buffer.Buffer('')
        b.set('<I',place.getId())
        b.addDummy(format='<II')
        b.set('<I',place.mainID)
        b.setString(place.town)
        b.setString(place.code)
        b.setString(place.department)
        b.setString(place.region)
        b.setString(place.country)
        b.addRaw('\x00' * 6)
        return b.buffer

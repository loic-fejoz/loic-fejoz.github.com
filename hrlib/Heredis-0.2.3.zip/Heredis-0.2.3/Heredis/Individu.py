#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

from __future__ import generators
import Item

class Individu(Item.Item):

    def __init__(self,offset=None,id=None,index=None):
        Item.Item.__init__(self,offset,id)
        self._index = id

    def __str__(self):
        return '<'+str(self.__class__)+'(@'+str(self._id)+','+str(self.name)+')>'

    def dump(self):
        print (self.unknown1,self.unknown2)
        print 'parents=',(self.fatherID,self.motherID)
        print 'surname=',self.surnameID
        print 'name=',self.name
        print 'activity=',self.activity
        print 'sex=',self.sex
        print 'note=',self.note
        print 'numero=',self.numero
        #10 user-specific fields
        for x in range(10):
            print 'champs',x,self.champs[x]
        print self.unknown4
        print 'sans Descendance=',self.sansDesc
        print self.signatureId,self.signature
        print self.enfantId,self.enfant
        print 'marqu� ?',self.marque
        print self.unknown5
        print 'confidentiel=',self.confidentiel
        print 'suffixe=',self.suffixe
        print 'surnom=',self.surnom
        print 'titre=',self.titre

    # Surname
    def getSurname(self):
        if self.heredisFile and self.surnameID:
            return self.heredisFile.getTable('TH5TableDicoNoms').getItemById(int(self.surnameID))

    def setSurname(self,surname):
        self.surnameID = surname.id

    surname = property(getSurname,setSurname)

    # Father
    def getFather(self):
        if self.heredisFile and self.fatherID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(int(self.fatherID))

    def setFather(self,father):
        self.fatherID = father.id

    father = property(getFather,setFather)

    # Mother
    def getMother(self):
        if self.heredisFile and self.motherID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(int(self.motherID))

    def setMother(self,mother):
        self.motherID = mother.id

    mother = property(getMother,setMother)


    # ids of events
    def getEventsIDs(self):
        if self.heredisFile:
            for evtIdx in self.heredisFile.getTable('TBEvent-Idx'):
                if evtIdx.indiID == self.id:
                    yield evtIdx.eventID

    eventsIDs = property(getEventsIDs,doc="ids of all events for this individu")

    # events
    def getEvents(self):
        tEvent = self.heredisFile.getTable('TH5TableEvenements')
        if tEvent.optimizer:
            for evt in tEvent.optimizer.getEventsForID(self.id):
                yield evt
        else:
            for evtID in self.eventsIDs:
                yield tEvent.getItemById(evtID)

    events = property(getEvents,doc="all events for this individu")

    # ids of unions
    def getUnionsIDs(self):
        """ unions where self is a wife or an husband """
        if self.heredisFile:
            tUnion = self.heredisFile.getTable('TH5TableUnion')
            if tUnion.optimizer:
                for unionID in tUnion.optimizer.getUnionsIDsForID(self.id):
                    yield unionID
            else:
                if self.sex == "m":
                    tableName = "TBUnion-IdxHusb"
                else:
                    tableName = "TBUnion-IdxSpouse"
                    for tbUnionIdx in self.heredisFile.getTable(tableName):
                        if tbUnionIdx.indiID == self.id:
                            yield tbUnionIdx.unionID

    unionsIDs = property(getUnionsIDs,doc="id of unions where this individu is a wife or an husband")

    # unions
    def getUnions(self):
        if self.heredisFile:
            tUnion = self.heredisFile.getTable('TH5TableUnion')
            if tUnion.optimizer:
                for union in tUnion.optimizer.getUnionsForID(self.id):
                    yield union
            else:
                for id in self.unionsIDs:
                    yield self.heredisFile.getTable('TH5TableUnion').getItemById(id)

    unions = property(getUnions,doc="unions where this individu is a wife or an husband")

    # family
    def getFamily(self):
        """ union where self is a child """
        if not self.father or not self.mother:
            return
        motherUnionsIDs = self.mother.unionsIDs
        for unionID in self.father.unionsIDs:
            if unionID in motherUnionsIDs:
                return self.heredisFile.getTable('TH5TableUnion').getItemById(unionID)

    familly = property(getFamily,doc="union where this individu is a child")

    # Address
    def getAddresses(self):
        """ addresses of self """
        if self.heredisFile:
            for address in self.heredisFile.getTable('TH5TableDicoAdresses'):
                if address.husbandID == self.id or address.wifeID == self.id:
                    yield address

    addresses = property(getAddresses,doc="address of this individu")


    # LinkMedias
    def getMediasLinks(self):
        if self.heredisFile:
            for linkMedia in self.heredisFile.getTable('TBMedia-IdxOwner'):
                if linkMedia.ownerID == self.id:
                    yield linkMedia

    mediasLinks = property(getMediasLinks,doc="links to medias of this individu")


    def getLinks(self):
        for link in []:
            yield link

    links = property(getLinks,doc="links this person is the origin")


    def getFullName(self):
        return "%s %s" % (self.name,self.surname.name)

    fullName = property(getFullName,doc="name + surname")

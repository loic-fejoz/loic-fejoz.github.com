#!/usr/bin/env python
__version__ = '$Revision: 1.0 $'
__author__ = ''
__date__ = ''

from __future__ import generators
import Item

class Union(Item.Item):

    def dump(self):
        print 'id=',self.getId()
        print self.unknown1,self.unknown2
        print self.husbandID,self.wifeID
        print 'note=',self.note


    # Husband
    def getHusband(self):
        if self.heredisFile and self.husbandID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(self.husbandID)

    def setHusband(self,husband):
        self.husbandID = husband.id

    husband = property(getHusband,setHusband)

    # Wife
    def getWife(self):
        if self.heredisFile and self.wifeID:
            return self.heredisFile.getTable('TH5TableIndividus').getItemById(self.wifeID)

    def setWife(self,wife):
        self.wifeID = wife.id

    wife = property(getWife,setWife)

    # ids of children
    def getChildrenID(self):
        if self.heredisFile:
            for quickList in self.heredisFile.getTable('QuickList'):
                if quickList.motherID == self.wifeID and quickList.fatherID == self.husbandID:
                    yield quickList.childID

    childrenID = property(getChildrenID)

    def getChildren(self):
        for childID in self.getChildrenID():
            yield self.heredisFile.getTable('TH5TableIndividus').getItemById(childID)

    children = property(getChildren)


    # events
    def getEvents(self):
        if self.heredisFile:
            tEvent =  self.heredisFile.getTable('TH5TableEvenements')
            if tEvent.optimizer:
                for evt in tEvent.optimizer.getEventsForID(self.id):
                    yield evt
            else:
                for evt in tEvent:
                    if evt.itemID == self.id:
                        yield evt

    events = property(getEvents,doc="all events for this individu")


    def getFullName(self):
        return "union de %s et %s" % (self.husband.fullName,self.wife.fullName)

    fullName = property(getFullName,doc="a description of the union")

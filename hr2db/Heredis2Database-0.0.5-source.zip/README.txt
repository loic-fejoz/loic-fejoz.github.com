--------
README
--------
Il faudrait que je synchronize le tout avec hrlib (http://hrlib.sourceforge.net/)
qui est depuis beaucoup plus performante et qui reprends plus de choses des fichiers Heredis.
A l'occasion je le mettrai sous sourceforge hrlib et hr2ged.

--------
Licence
--------
Les sources sont sous licence CNU/GPL. Il faudrait que je fasse cela proprement mais j'ai pas le temps.

--------
Contact
--------
loic@fejoz.net
http://www.fejoz.net/Ressources/Heredis2Database
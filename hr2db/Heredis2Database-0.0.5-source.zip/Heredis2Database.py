# -*- coding: mbcs -*-
import BddInterface
import HeredisObject
import HeredisFile
import datetime
import time
import sys
if 1:
    import warnings
    warnings.filterwarnings('ignore')
import Constants
import logging

refDate = datetime.date(1899,12,30)

def copyDates(self,other):
    """ translate days in datetime object """
    d = refDate + datetime.timedelta(days=other.creationDate)
    self.creationDate = d
    d = refDate + datetime.timedelta(days=other.modificationDate)
    self.modificationDate = d

def simpleTranslation(cursor,hdb,hf,nomObj,generatorName,new):
    """ for all object from the generator create a new object in the database """
    for obj in getattr(hf,generatorName)():
        error = False
        bddObj = hdb.getNewObject(nomObj)
        bddObj.copy(obj)
        copyDates(bddObj,obj)
        bddObj.insert(cursor)

def Heredis2Database(fileName,dbName,type,host,user,password,replaceTable=False,flushTable=True,tables='ALL'):
    print '-'*20,type,'-'*20
    bdd = BddInterface.getBdd(type)
    bdd.connect(host,user,password,dbName)
    new = bdd.newDatabase
    bdd.getObjectFromModule(HeredisObject)
    if tables == 'ALL':
        bdd.tablesList = bdd.tables.keys()
    else:
        bdd.tablesList = tables.split(',')
    tables = bdd.tablesList
    debut = time.time()
    bdd.createTables(replaceTable)
    if replaceTable:
        new = True
    if flushTable:
        new = True
        bdd.flushTables()
    hf = HeredisFile.HeredisFile(fileName)
    cursor = bdd.cursor()
    avant = time.time()
    print 'preparation :',avant-debut
    print 'adding constants'
    Constants.addConstants(bdd,new)
    if 'Surname' in tables:
        print 'adding noms'
        simpleTranslation(cursor,bdd,hf,'Surname','SurnameGenerator',new)
    if 'Individu' in tables:
        print 'adding individus'
        simpleTranslation(cursor,bdd,hf,'Individu','IndividuGenerator',new)
    if 'Unions' in tables:
        print 'adding unions'
        simpleTranslation(cursor,bdd,hf,'Unions','UnionsGenerator',new)
    if 'Events' in tables:
        print 'adding Events'
        #simpleTranslation(cursor,bdd,hf,'Events','EventsGenerator',new)
        for event in hf.EventsGenerator():
            bddEvent = bdd.getNewObject('Events')
            bddEvent.copy(event)
            copyDates(bddEvent,event)
            bddEvent.year1 = event.selectYear1 * 256 + event.partYear1
            bddEvent.year2 = event.selectYear2 * 256 + event.partYear2
            bddEvent.insert(cursor)
    if 'Place' in tables:
        print 'adding places'
        simpleTranslation(cursor,bdd,hf,'Place','PlaceGenerator',new)
    if 'Adresse' in tables:
        print 'adding Adresses'
        simpleTranslation(cursor,bdd,hf,'Adresse','AdresseGenerator',new)
    if 'Source' in tables:
        print 'adding Sources'
        simpleTranslation(cursor,bdd,hf,'Source','SourceGenerator',new)
    if 'Media' in tables:
        print 'adding Medias'
        #simpleTranslation(cursor,bdd,hf,'Media','MediaGenerator')
        for media in hf.MediaGenerator():
            bddMedia = bdd.getNewObject('Media')
            bddMedia.copy(media)
            copyDates(bddMedia,media)
            bddMedia.year = media.year2 * 256 + media.year1
            bddMedia.thumbnail=None
            bddMedia.insert(cursor)
    if 'Link' in tables:
        print 'adding Links'
        simpleTranslation(cursor,bdd,hf,'Link','LinkGenerator',new)
    if 'LinkDoc' in tables:
        print 'adding Links Doc'
        simpleTranslation(cursor,bdd,hf,'LinkDoc','LinkDocGenerator',new)
    if 'LinkMedia' in tables:
        print 'adding Links Media'
        simpleTranslation(cursor,bdd,hf,'LinkMedia','LinkMediaGenerator',new)
    creation = time.time()
    print 'creation :',creation-avant
    return bdd

def test():
    import Misc
    logger =  Misc.setLogger(sys.argv[0]+'.log')
    h2dLogger= logging.getLogger('Heredis2Database')
    h2dLogger.info('Test')
    fileName = sys.argv[1]
    h2dLogger.info('fileName : %s',fileName)
    for type in ['ACCESS','MYSQL','GADFLY']:
        h2dLogger.info('Test du type %s',type)
        bdd = Heredis2Database(fileName,'test1',type,'localhost','root','',True,True)
        print 'OK FINISHED ! '
        c = bdd.cursor()
        c.execute("SELECT count(*) FROM Individu")
        print 'Nb individus :',c.fetchone()[0]
    h2dLogger.info('Good Bye')
    logging.shutdown()

def interactive():
    import optparse
    parser = optparse.OptionParser(usage="%prog [options] fichier_heredis database_name")
    parser.add_option("-t", "--type",
                      action="store", dest="type", default='MYSQL',
                      help="type de la base de donnees : MYSQL [default], ACCESS, ODBC, GADFLY")
    parser.add_option("-m", "--host", dest="host", default='localhost',
                      help="machine de la base de donnees")
    parser.add_option("-u", "--user", dest="user", default='',
                      help="utilisateur de connexion a la base")
    parser.add_option("-p", "--password",dest="password",default='',
                      help="mot de passe de l'utilisateur de connexion")
    parser.add_option("-r", "--replace",
                      action="store_true", dest="replace", default=False,
                      help="remplace la definition des tables existantes")
    parser.add_option("-f", "--flush",
                      action="store_true", dest="flush", default=False,
                      help="vide les tables avant de les remplir")
    parser.add_option("-l", "--list", dest="tables", default='ALL',
                      help="liste des tables a inserer/mettre a jour")
    (options, args) = parser.parse_args()
    if len(args) != 2:
        print "nombre  d'arguments  incorrect"
        parser.print_help()
        print
        print 'Exemple :'
        print "Heredis2Database -tMYSQL -uloic -ploicpassword -f fejoz.hr7 fejoz"
        print "Heredis2Database -tMYSQL -uloic -f fejoz.hr7 fejoz"
        print "Heredis2Database -tACCESS fejoz.hr5 fejoz"
        print "Heredis2Database -tGADFLY fejoz.hr5 fejoz"
        print "Heredis2Database -lSource,Adresse fejoz.hr5 fejoz"
        sys.exit(1)
    import Misc
    logger =  Misc.setLogger(sys.argv[0]+'.log')
    h2dLogger= logging.getLogger('Heredis2Database')
    try:
        h2dLogger.info('options : %s  %s',str(options),str(args))
        Heredis2Database(args[0],args[1],
                         options.type,
                         options.host,
                         options.user,options.password,
                         options.replace,
                         options.flush,options.tables).close()
    except:
        h2dLogger.exception('Erreur critique ! !')
        import traceback
        traceback.print_exc(0)
        print 
        print "Si l'erreur provient de votre fichier,"
        print "pourriez-vous l'envoyer a loic@fejoz.net pour debugging,"
        print "ainsi que le fichier %s merci." % (sys.argv[0]+'.log')
    h2dLogger.info('Good Bye')
    logging.shutdown()
        

if __name__=='__main__':
    #test()
    interactive()

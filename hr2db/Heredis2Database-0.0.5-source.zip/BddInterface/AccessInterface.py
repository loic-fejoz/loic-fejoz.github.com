import ODBCInterface

def getBoolean(self,val):
    return val and 1 or 0

def getString(self,val):
    if type(val) == type(u''):
        return val.encode('latin1')
    else:
        return str(val)

def getInt(self,val):
    return (val!=None) and str(val) or '0'

class AccessInterface(ODBCInterface.ODBCInterface):
    def __init__(self):
        super(AccessInterface,self).__init__()
        translateType = self.translateType
        X = type('Access'+translateType.__name__,(translateType,),{})
        setattr(X,'typeBoolean',getBoolean)
        setattr(X,'typeString',getString)
        setattr(X,'typeInt',getInt)
        self.translateType = X
        
##    def getSubClass(self,cls):
##        subClass = super(AccessInterface,self).getSubClass(cls)
##        return subClass

def iterateOnCursor(cursor):
    r = True
    while r:
        try:
            r = cursor.fetchone()
            if r:
                yield r
        except:
            r = False

def setAttributes(obj,cursor,result):
    for (i,desc) in enumerate(cursor.description):
        attrName = desc[0]
        setattr(obj,attrName,result[i])

def getModule(type):
    type = type.upper()
    if type=='ODBC':
        import ODBCInterface
        return ODBCInterface.ODBCInterface()
    elif type=='ACCESS':
        import AccessInterface
        return AccessInterface.AccessInterface()
    elif type=='MYSQL':
        import MySQLInterface
        return MySQLInterface.MySQLInterface()
    elif type=='GADFLY':
        import GadflyInterface
        return GadflyInterface.GadflyInterface()
    else:
        raise ValueError,"%s n'est pas un type correct" % type

def getBdd(type):
    import Bdd
    return Bdd.Bdd(getModule(type))

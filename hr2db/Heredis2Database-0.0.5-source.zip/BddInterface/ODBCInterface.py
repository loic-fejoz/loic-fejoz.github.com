import ModuleBddInterface

class ODBCInterface(ModuleBddInterface.ModuleBddInterface):
    typesMapping = {'Short':'SMALLINT',
                    'Int':'INTEGER',
                    'String':'TEXT',
                    'Date':'DATE',
                    'Char':'SMALLINT',
                    'Boolean':'BIT',
                    'Binary':'BINARY'}

    def __init__(self):
        import odbc as m
        m.paramstyle = 'qmark'
        super(ODBCInterface,self).__init__(m)

    def connect(self,host=None,user=None,password=None,dbName=None):
        db = self.module.odbc(dbName)
        return (db,False)

    def getSQLCreate(self,cls):
        l = super(ODBCInterface,self).getSQLCreate(cls)
        id = self.getId(cls)
        l.append("CREATE UNIQUE INDEX %s_id ON %s (%s)" % (cls.__name__,cls.__name__,id))
        return l

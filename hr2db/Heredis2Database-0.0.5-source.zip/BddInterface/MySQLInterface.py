import ModuleBddInterface

class MySQLInterface(ModuleBddInterface.ModuleBddInterface):
    typesMapping = {'Short':'SMALLINT',
                    'Int':'INTEGER',
                    'String':'TEXT',
                    'Date':'DATE',
                    'Char':'SMALLINT',
                    'Boolean':'BOOL',
                    'Binary':'BLOB'}

    def __init__(self):
        import MySQLdb as m
        super(MySQLInterface,self).__init__(m)

    def connect(self,host=None,user=None,password=None,dbName=None):
        db = self.module.connect(host=host,user=user)
        newDatabase = False
        try:
            db.select_db(dbName)
        except:
            # la base n'existe pas
            c = db.cursor()
            c.execute("create database %s" % dbName)
            db.select_db(dbName)
            newDatabase = True
        return (db,newDatabase)

    def getSQLCreate(self,cls):
        """ get the Create SQL """
        r = "CREATE TABLE %s (" % cls.__name__
        l = ["%s %s%s" % (attr,self.getType(type,flags),self.getFlags(attr,type,flags)) for (attr,type,flags) in cls.attr]
        r += ','.join(l)
        id = self.getId(cls)
        r += ', PRIMARY KEY (`%s`)' % id + ')'
        return  [r]
    
    def getType(self,type,flags={}):
        if ('PrimaryKey' in flags) and flags['PrimaryKey'] and type=="String":
            # if type is String and it is a primary key then use VARCHAR
            return 'VARCHAR(255)'
        else:
            return super(MySQLInterface,self).getType(type,flags)

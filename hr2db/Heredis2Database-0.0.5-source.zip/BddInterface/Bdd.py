import BddInterface

class Bdd(object):
    def __init__(self,bddInterface):
        import logging
        self.logger = logging.getLogger('Bdd')
        self.bddInterface = bddInterface
        self.tables = {}
        self.newDatabase = False
        self.getMarks = lambda attrList:self.bddInterface.getMarks(attrList)

    def getAttrs(self,attrList):
        """help to create simple select statement when use unknown part
        for exemple : getWhere(['a','b']) will return ['a=?','b=?'] with gadfly"""
        marks = self.getMarks(attrList)
        return ["%s=%s" % (attr,mark) for (attr,mark) in zip(attrList,marks)]

    def connect(self,host=None,user=None,password=None,dbName=None):
        self.logger.info('Ouverture de host=%s, user=%s, password=%s, dbName=%s',host,user,password,dbName)
        self.name = dbName
        (self._db,self.newDatabase) = self.bddInterface.connect(host,user,password,dbName)

    def commit(self):
        self._db.commit()

    def addObject(self,cls):
        """ add the given class in the database """
        subCls = self.bddInterface.getSubClass(cls)
        self.tables[subCls.tableName] = subCls
        self.tablesList = self.tables.keys()
        #print 'adding',subCls.tableName

    def getObjectFromModule(self,module):
        """ add all objects from the given module in the database.
        Does not import object which name begin with 2 underscores.
        """
        for attr in dir(module):
            obj = getattr(module,attr)
            if attr[:2] != '__' and type(obj)==type(Bdd):
                self.addObject(obj)
        self.tablesList = self.tables.keys()

    def createTables(self,replace=False):
        """ execute the SQL code that will create the tables """
        for obj in self.tables.itervalues():
            if obj.tableName in self.tablesList:
                if replace and not self.newDatabase:
                    print "trying to erase %s" % obj.tableName
                    self.logger.info('drop table %s',obj.tableName)
                    try:
                        self.executeSQL("drop table %s" % obj.tableName)
                    except:
                        print "does not exist ?"
                        self.logger.exception("la table n'existe pas ? ")
                for sql in obj.SqlCreate:
                    self.logger.info(sql)
                    try:
                        self.executeSQL(sql)
                    except:
                        self.logger.exception('la table existe deja ?')
                        if self.newDatabase or replace:
                            print 'Erreur avec %s' % obj.tableName

    def flushTables(self):
        """ flush all the tables """
        self.logger.info('vidage des tables')
        c = self._db.cursor()
        for tableName in self.tablesList:
            try:
                c.execute('DELETE FROM %s' % tableName)
            except:
                self.logger.exception('DELETE FROM %s',tableName)

    def executeSQL(self,sql):
        c = self._db.cursor()
        c.execute(sql)
        if hasattr(c,'commit'):
            c.commit()
        if hasattr(self._db,'commit'):
            self._db.commit()

    def cursor(self):
        return self._db.cursor()

    def getNewObject(self,tableName):
        return self.tables[tableName]()

    def getObject(self,tableName,id):
        cursor = self.cursor()
        sql = self.tables[tableName].SqlSelect
        result = None
        try:
            cursor.execute(sql,id)
        except:
            self.logger.exception('%s:%s',tableName,sql)
        else:
            result = cursor.fetchone()
        obj = self.tables[tableName]()
        obj.id = id
        if result:
            BddInterface.setAttributes(obj,cursor,result)
        return obj

    def close(self):
        self._db.close()
        self.logger.info('Fermeture de la bdd')

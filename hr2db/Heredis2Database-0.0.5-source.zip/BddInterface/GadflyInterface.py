import ModuleBddInterface

class GadflyInterface(ModuleBddInterface.ModuleBddInterface):
    typesMapping = {'Short':'INTEGER',
                    'Int':'INTEGER',
                    'String':'VARCHAR',
                    'Date':'VARCHAR',
                    'Char':'INTEGER',
                    'Boolean':'INTEGER',
                    'Binary':'VARCHAR'}

    def __init__(self):
        import gadfly as m
        m.paramstyle = 'qmark'
        super(GadflyInterface,self).__init__(m)

    def connect(self,host=None,user=None,password=None,dbName=None):
        newDatabase = False
        try:
            db = self.module.gadfly(dbName,dbName)
        except:
            # la base n'existe pas
            import os
            try:
                os.mkdir(dbName)
            except:
                pass
            db = self.module.gadfly()
            db.startup(dbName,dbName)
            newDatabase = True
        return (db,newDatabase)

    def getSQLCreate(self,cls):
        l = super(GadflyInterface,self).getSQLCreate(cls)
        id = self.getId(cls)
        l.append("CREATE UNIQUE INDEX %s_id ON %s (%s)" % (cls.__name__,cls.__name__,id))
        return l

import logging
class BddObject(object):
    """ base for all object in the Database """
    def __init__(self):
        for (attr,type,flags) in self.attr:
            setattr(self,attr,None)

    def copy(self,other):
        """ try to set all the attributes from the other's attributes """
        for (attr,type,flags) in self.attr:
            if hasattr(other,attr):
                setattr(self,attr,getattr(other,attr))

    def getId(self):
        """ return the id of this object """
        return getattr(self,self.idName)

    def setId(self,newId):
        """ set the id of this object """
        setattr(self,self.idName,newId)

    id = property(getId,setId,doc='id')

    def __list__(self,withID=False):
        """ return object's attributes value as a list """
        l = []
        for (attr,type,flags) in self.attr:
            l.append(getattr(self,'type'+type)(getattr(self,attr)))
        if withID:
            (type,flags) = self.attrDict[self.idName]
            l.append(getattr(self,'type'+type)(getattr(self,self.idName)))
        return l

    def __tuple__(self,withID=False):
        """ return object's attributes value as a tuple """
        return tuple(self.__list__(withID))

    def __dico__(self,withID=False):
        """ return object's attributes value as a dict """
        d = {}
        for (attr,type,flags) in self.attr:
            d[attr]=getattr(self,'type'+type)(getattr(self,attr))
        return d

    def insert(self,cursor):
        """ insert the current object in the databse using the given cursor """
        try:
            cursor.execute(self.SqlInsert,self.getAttributes())
        except:
            logger = logging.getLogger('Bdd')
            logger.exception('%s %s',self.SqlInsert,self.getAttributes())
            raise

    def update(self,cursor):
        """ update the current object in the databse using the given cursor """
        try:
            cursor.execute(self.SqlUpdate,self.getAttributes(True))
        except:
            logger = logging.getLogger('Bdd')
            logger.exception('%s %s',self.SqlUpdate,self.getAttributes(True))
            raise

    def updateOrInsert(self,cursor,new=False):
        """ update the object if it already exist or insert it """
        if new:
            self.insert(cursor)
        else:
            try:
                cursor.execute(self.SqlInsert,self.getAttributes())
            except:
                self.update(cursor)
                

    def show(self):
        """ print all the attributes value """
        print self.tableName
        for (attr,type,flags) in self.attr:
            print '\t',attr,'=',getattr(self,attr)

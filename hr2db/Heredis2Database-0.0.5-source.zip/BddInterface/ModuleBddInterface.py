class TranslateType(object):
    """ use to translate value in correct object
    inherited by the SubClass (see getSubClass)
    """
    
    def typeIdentical(self,val):
        return val
    
    def typeDate(self,val):
        if hasattr(val,'strftime'):
            return val.strftime('%Y-%m-%d')
        else:
            return val
    typeString = typeIdentical
    typeShort = typeIdentical
    typeInt = typeIdentical
    typeChar = typeIdentical
    typeBoolean = typeIdentical
    typeBinary = typeIdentical

class ModuleBddInterface(object):
    typesMapping = {}
    
    def __init__(self,moduleDb):
        self.module = moduleDb
        self.translateType = TranslateType

    def connect(self,host=None,user=None,password=None,dbName=None):
        """ connect to the given database or create it.
        return a tuple : (db,newDatabase)
        """
        raise NotImplementedError 

    def getSubClass(self,cls):
        """ return a sub class of the given class with some additionnal attributes """
        X = type('Sub'+cls.__name__,(cls,self.translateType),{})
        self.__setSubClass(X,cls)
        return X

    def __setSubClass(self,X,cls):
        setattr(X,'tableName',cls.__name__)
        setattr(X,'SqlSelect',self.getSQLSelect(cls))
        setattr(X,'SqlSelectAll',"SELECT * FROM %s" % cls.__name__)
        setattr(X,'SqlInsert',self.getSQLInsert(cls))
        setattr(X,'SqlUpdate',self.getSQLUpdate(cls))
        setattr(X,'SqlCreate',self.getSQLCreate(cls))
        setattr(X,'idName',self.getId(cls))
        attrDict = {}
        for (attr,type,flags) in cls.attr:
            attrDict[attr] = (type,flags)
        setattr(X,'attrDict',attrDict)
        if self.module.paramstyle == 'qmark':
            setattr(X,'getAttributes',cls.__tuple__)
        elif self.module.paramstyle == 'numeric':
            setattr(X,'getAttributes',cls.__tuple__)
        elif self.module.paramstyle == 'named':
            setattr(X,'getAttributes',cls.__dico__)
        elif self.module.paramstyle == 'format':
            setattr(X,'getAttributes',cls.__tuple__)
        elif self.module.paramstyle == 'pyformat':
            setattr(X,'getAttributes',cls.__dico__)
        else:
            setattr(X,'getAttributes',cls.__tuple__)

    def getMarks(self,attrList):
        """ return a list of mark (see paramstyle)"""
        l =[]
        i = 1
        for attr in attrList:
            if self.module.paramstyle == 'qmark':
                l.append('?')
            elif self.module.paramstyle == 'numeric':
                l.append(':%d' % i)
            elif self.module.paramstyle == 'named':
                l.append(':%s' % attr)
            elif self.module.paramstyle == 'format':
                l.append('%s')
            elif self.module.paramstyle == 'pyformat':
                l.append('%(' + attr + ')s')
            else:
                l.append('?')
            i += 1
        return l

    def getType(self,type,flags={}):
        """ return the real type for the given type """
        fk = 'ForeignKeyTo' in flags and flags['ForeignKeyTo']
        if fk and not isinstance(fk,str):
            # if this is a foreign key then use the same type
            (attr,type,flags) = self.getIdProperties(fk)
            type = self.getType(type,flags)
            return type
        elif type in self.typesMapping:
            # else look in the dict
            return self.typesMapping[type]
        else:
            # else return the same...
            return type

    def getSQLSelect(self,cls):
        """ get the Select SQL """
        id = self.getId(cls)
        mark = self.getMarks([id])
        return "SELECT * FROM %s WHERE %s=%s" % (cls.__name__,id,mark[0])

    def getSQLInsert(self,cls):
        """ get the Insert SQL """
        r = "INSERT INTO %s (" % cls.__name__
        attrs = [attr for (attr,type,flags) in cls.attr]
        marks = self.getMarks(attrs)
        r += ','.join(attrs)
        r +=") VALUES (" + ','.join(marks) + ")"
        return r

    def getSQLUpdate(self,cls):
        """ get the Update SQL """
        r = "UPDATE %s SET " % cls.__name__
        attrs = [attr for (attr,type,flags) in cls.attr]
        marks = self.getMarks(attrs)
        l = ["%s=%s" % (attr,mark) for (attr,mark) in zip(attrs,marks)]
        r += ','.join(l)
        id = self.getId(cls)
        mark = self.getMarks([id])[0]
        r += " WHERE %s=%s" % (id,mark)
        return r

    def getFlags(self,attr,type,flags):
        def primary(flags):
            """ return flags[PrimaryKey] or False"""
            if 'PrimaryKey' in flags:
                return flags['PrimaryKey']
            else:
                return False
        def null(flags):
            """ return flags['Null'] or True"""
            if 'Null' in flags:
                return flags['Null']
            else:
                return True
        if primary(flags) or not null(flags):
            return ' NOT NULL'
        else:
            return ""

    def getSQLCreate(self,cls):
        """ get the Create SQL """
        r = "CREATE TABLE %s (" % cls.__name__
        l = ["%s %s%s" % (attr,self.getType(type),self.getFlags(attr,type,flags)) for (attr,type,flags) in cls.attr]
        r += ','.join(l)
        r += ')'
        return [r]

    def getId(self,cls):
        """ return the attr name which is the primary key of the table or None"""
        for (attr,type,flags) in cls.attr:
            if 'PrimaryKey' in flags:
                if flags['PrimaryKey']:
                    return attr
        return None

    def getIdProperties(self,cls):
        """ return the attr name which is the primary key of the table or None"""
        for (attr,type,flags) in cls.attr:
            if 'PrimaryKey' in flags:
                if flags['PrimaryKey']:
                    return (attr,type,flags)
        return None

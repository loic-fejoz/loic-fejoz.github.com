def setLogger(fileName):
    import logging
    logger = logging.getLogger()
    hdlr = logging.FileHandler(fileName,'w')
    formatter = logging.Formatter('%(name)s : %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr) 
    logger.setLevel(logging.NOTSET)
    return logger


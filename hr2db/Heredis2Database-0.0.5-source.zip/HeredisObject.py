import BddInterface.BddObject
class Individu(BddInterface.BddObject.BddObject):
    attr = [("individuID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("fatherID","Int",{'foreignKeyTo':'Individu'}),
            ("motherID","Int",{'foreignKeyTo':'Individu'}),
            ("surnameID","Int",{'foreignKeyTo':'Surname'}),
            ("unknown1","Int",{}),
            ("name","String",{}),
            ("activity","String",{}),
            ("sex","String",{}),
            ("notes","String",{}),
            ("numero","String",{}),
            ("userField0","String",{}),
            ("userField1","String",{}),
            ("userField2","String",{}),
            ("userField3","String",{}),
            ("userField4","String",{}),
            ("userField5","String",{}),
            ("userField6","String",{}),
            ("userField7","String",{}),
            ("userField8","String",{}),
            ("userField9","String",{}),
            ("userField10","String",{}),
            ("sansDesc","Short",{}),
            ("signatureIndex","Char",{}),
            ("enfantIndex","Char",{}),
            ("marque","Char",{}),
            ("confidentiel","Char",{}),
            ("suffixe","String",{}),
            ("surnom","String",{}),
            ("titre","String",{})]

class Surname(BddInterface.BddObject.BddObject):
    attr = [("surnameID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("mainSurnameID","Int",{'foreignKeyTo':'Surname'}),
            ("name" ,"String",{})]

class Events(BddInterface.BddObject.BddObject): 
    attr = [("eventID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("itemID","Int",{'foreignKeyTo':'all'}),
            ("eventType","Char",{}),
            ("placeID","Int",{'foreignKeyTo':'Place'}),
            ("calendar1","Int",{}),
            ("calendar2","Int",{}),
            ("modif1","Int",{}),
            ("modif2","Int",{}),
            ("day1","Int",{}),
            ("day2","Int",{}),
            ("month1","Int",{}),
            ("month2","Int",{}),
            ("modif3","Int",{}),
            ("year1","Int",{}),
            ("year2","Int",{}),
            ("hour","Int",{}),
            ("minute","Int",{}),
            ("unknown2","String",{}),
            ("notes","String",{}),
            ("placeSubdivision","String",{}),
            ("name","String",{}),
            ("ageOnAct","String",{}),
            ("findTheSource","Boolean",{})]

class Unions(BddInterface.BddObject.BddObject):
    attr = [("unionID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("husbandID","Int",{'foreignKeyTo':'Individu'}),
            ("wifeID","Int",{'foreignKeyTo':'Individu'}),
            ("notes","String",{})]

class Place(BddInterface.BddObject.BddObject):
    attr = [("placeID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("mainPlaceID","Int",{'foreignKeyTo':'Place'}),
            ("town","String",{}),
            ("code","String",{}),
            ("department","String",{}),
            ("region","String",{}),
            ("country","String",{})]

class Adresse(BddInterface.BddObject.BddObject):
    attr = [("adresseID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),    
            ("unionID","Int",{'foreignKeyTo':'Unions'}),
            ("husbandID","Int",{'foreignKeyTo':'Individu'}),
            ("wifeID","Int",{'foreignKeyTo':'Individu'}),
            ("private","Boolean",{}),
            ("contact","String",{}),
            ("line1","String",{}),
            ("line2","String",{}),
            ("postalCode","String",{}),
            ("town","String",{}),
            ("country","String",{}),
            ("phone","String",{}),
            ("fax","String",{}),
            ("email","String",{}),
            ("region","String",{})]

class Source(BddInterface.BddObject.BddObject):
    attr = [("sourceID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),    
            ("origin","String",{}),
            ("document","String",{}),
            ("cote","String",{}),
            ("archivage","String",{}),
            ("type","Short",{}),
            ("notes","String",{}),
            ("name","String",{})]

class Media(BddInterface.BddObject.BddObject):
    attr = [("mediaID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),    
            ("directory","String",{}),
            ("fileName","String",{}),
            ("comment","String",{}),
            ("thumbnailLength","Int",{}),
            ("year","Int",{}),
            ("thumbnail","Binary",{})]

class Link(BddInterface.BddObject.BddObject):
    attr = [("linkID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("fromItemID","Int",{'foreignKeyTo':'all'}),
            ("toItemID","Int",{'foreignKeyTo':'all'}),
            ("notes","String",{}),
            ("typeIndex","Char",{})]

class LinkDoc(BddInterface.BddObject.BddObject):
    attr = [("linkDocID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("evtID","Int",{'foreignKeyTo':'Event'}),
            ("sourceID","Int",{'foreignKeyTo':'Source'}),
            ("notes","String",{})]

class LinkMedia(BddInterface.BddObject.BddObject):
    attr = [("linkMediaID","Int",{'PrimaryKey':True}),
            ("creationDate","Date",{}),
            ("modificationDate","Date",{}),
            ("ownerID","Int",{'foreignKeyTo':'all'}),
            ("mediaID","Int",{'foreignKeyTo':'Media'}),
            ("mainMedia","Int",{})]


class __Constant(BddInterface.BddObject.BddObject):
    attr = [('constantId','Int',{'PrimaryKey':True}),
            ('valeur','String',{})]
    
class SourceType(__Constant):
    pass

class IndividuSignature(__Constant):
    pass

class IndividuEnfant(__Constant):
    pass

class EventType(__Constant):
    pass

class LinkType(__Constant):
    pass


class DateCalendar(__Constant):
    pass

class DateModifier(__Constant):
    pass

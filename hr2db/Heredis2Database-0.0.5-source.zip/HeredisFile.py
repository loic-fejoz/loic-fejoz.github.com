import sys
import struct
import Buffer
import unpack

class HeredisError(Exception):
    """ Erreur specifique au fichier Heredis """

def cString2String(obj):
    i = obj.find('\x00')
    if i != -1:
        return obj[:i]
    else:
        return obj

class HeredisFile:
    def  __init__(self,fileName):
        import logging
        self.logger = logging.getLogger('HeredisFile')
        self.fileName = fileName
        tables={}
        for h in self.headersGenerator():
            tables[h[1]]=h
            #print h
        self.headers = tables


    def headersGenerator(self):
        f = file(self.fileName,'rb')
        f.seek(2380)
        pos = f.tell()
        buffer = f.read(80)
        while buffer:
            (code,name,itemSize,nbItem,tableSize) = struct.unpack("<4s40s12s12s12s",buffer)
            try:
                (name,itemSize,nbItem,tableSize) = (cString2String(name),int(itemSize[:-1]),int(nbItem[:-1]),int(tableSize[:-1]))

            except:
                self.logger.exception('entete de table invalide : %s',(code,name,itemSize,nbItem,tableSize))
                raise HeredisError,"Entete de table invalide"
            if code != '\xC0\xDE\xCA\xFE':
                print 'erreur : entete de table invalide'
                self.logger.critical("code d'entete de table invalide : %s",code)
            f.seek(pos+tableSize+80)
            self.logger.info("header %s",str((pos,name,itemSize,nbItem,tableSize)))
            yield (pos,name,itemSize,nbItem,tableSize)
            pos = f.tell()
            buffer = f.read(80)
        f.close()

    def itemSizesGenerator(self,tableName):
        try:
            h = self.headers[tableName]
        except KeyError:
            self.logger.info("la table %s n'existe pas",tableName)
            return
        f = file(self.fileName,'rb')
        pos = h[0] + 80 +  4
        endPos = h[0]+80+h[4]
        offset = 0
        while pos < endPos:
            f.seek(pos)
            b = f.read(4)
            o = struct.unpack('<I',b)[0]
            pos+=4
            size = o-offset
            if size < 0:
                print o,offset
            yield size
            offset = o
        f.close()

    def itemGenerator(self,tableName,unpack,itemSizeTableName=None):
        if not itemSizeTableName:
            itemSizeTableName = tableName+'-ItemSize'
        try:
            hItem = self.headers[tableName]
        except KeyError:
            self.logger.info("la table %s n'existe pas",tableName)
            return
        f = file(self.fileName,'rb')
        pos = hItem[0]
        pos += 80
        for size in self.itemSizesGenerator(itemSizeTableName):
            f.seek(pos)
            if size <= 0:
                raise HeredisError,"table des tailles incoherentes"
            else:
                b = f.read(size)
#            b = getNBytes(f,size)
            pos += size
            try:
                yield unpack(Buffer.Buffer(b))
            except:
                self.logger.exeception("Erreur dans la table %s",tableName)
                raise HeredisError,"Erreur dans la table %s" % tableName
        f.close()

unpack.addItemsGenerator(HeredisFile)

def getNBytes(f,n):
    if n<0:
        raise HeredisError,"table des tailles incoherentes"
    b = ''
    while len(b) != n:
        b += f.read(n-len(b))
    return b
    
def test():
    hf = HeredisFile(sys.argv[1])
    i = 1
    for  indi in hf.IndividuGenerator():
        print i,indi.name
        i+=1
    i = 1

if __name__=='__main__':
    test()

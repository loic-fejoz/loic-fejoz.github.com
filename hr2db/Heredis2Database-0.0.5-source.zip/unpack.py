class Result:
	pass

def unpackIndividu(buffer):
	result = Result()
	result.individuID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.fatherID = buffer.get('<I')[0]
	result.motherID = buffer.get('<I')[0]
	result.surnameID = buffer.get('<I')[0]
	result.unknown1 = buffer.get('<I')[0]
	result.name = buffer.getString()
	result.activity = buffer.getString()
	result.sex = buffer.getString()
	result.notes = buffer.getString()
	result.numero = buffer.getString()
	result.userField0 = buffer.getString()
	result.userField1 = buffer.getString()
	result.userField2 = buffer.getString()
	result.userField3 = buffer.getString()
	result.userField4 = buffer.getString()
	result.userField5 = buffer.getString()
	result.userField6 = buffer.getString()
	result.userField7 = buffer.getString()
	result.userField8 = buffer.getString()
	result.userField9 = buffer.getString()
	result.userField10 = buffer.getString()
	result.unknown2 = buffer.get('<H')[0]
	result.sansDesc = buffer.get('<H')[0]
	result.signatureIndex = buffer.get('<B')[0]
	result.enfantIndex = buffer.get('<B')[0]
	result.marque = buffer.get('<B')[0]
	result.unknown3 = buffer.get('<B')[0]
	result.confidentiel = buffer.get('<B')[0]
	result.suffixe = buffer.getString()
	result.surnom = buffer.getString()
	result.titre = buffer.getString()
	return result

def unpackSurname(buffer):
	result = Result()
	result.surnameID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.mainSurnameID = buffer.get('<I')[0]
	result.name = buffer.getString()
	return result

def unpackUnions(buffer):
	result = Result()
	result.unionID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.husbandID = buffer.get('<I')[0]
	result.wifeID = buffer.get('<I')[0]
	result.unknown1 = buffer.get('<I')[0]
	result.notes = buffer.getString()
	return result

def unpackEvents(buffer):
	result = Result()
	result.eventID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.itemID = buffer.get('<I')[0]
	result.eventType = buffer.get('<B')[0]
	result.placeID = buffer.get('<I')[0]
	result.unknown1 = buffer.get('<B')[0]
	result.calendar1 = buffer.get('<B')[0]
	result.calendar2 = buffer.get('<B')[0]
	result.modif1 = buffer.get('<B')[0]
	result.modif2 = buffer.get('<B')[0]
	result.day1 = buffer.get('<B')[0]
	result.day2 = buffer.get('<B')[0]
	result.month1 = buffer.get('<B')[0]
	result.month2 = buffer.get('<B')[0]
	result.modif3 = buffer.get('<B')[0]
	result.partYear1 = buffer.get('<B')[0]
	result.selectYear1 = buffer.get('<B')[0]
	result.partYear2 = buffer.get('<B')[0]
	result.selectYear2 = buffer.get('<B')[0]
	result.hour = buffer.get('<B')[0]
	result.minute = buffer.get('<B')[0]
	result.unknown2 = buffer.get('<16B')[0]
	result.notes = buffer.getString()
	result.placeSubdivision = buffer.getString()
	result.name = buffer.getString()
	result.unknown3 = buffer.get('<H')[0]
	result.ageOnAct = buffer.getString()
	result.findTheSource = buffer.get('<B')[0]
	return result

def unpackPlace(buffer):
	result = Result()
	result.placeID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.mainPlaceID = buffer.get('<I')[0]
	result.town = buffer.getString()
	result.code = buffer.getString()
	result.department = buffer.getString()
	result.region = buffer.getString()
	result.country = buffer.getString()
	return result

def unpackAdresse(buffer):
	result = Result()
	result.adresseID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.unionID = buffer.get('<I')[0]
	result.husbandID = buffer.get('<I')[0]
	result.wifeID = buffer.get('<I')[0]
	result.private = buffer.get('<H')[0]
	result.unknown1 = buffer.get('<B')[0]
	result.contact = buffer.getString()
	result.line1 = buffer.getString()
	result.line2 = buffer.getString()
	result.postalCode = buffer.getString()
	result.town = buffer.getString()
	result.country = buffer.getString()
	result.phone = buffer.getString()
	result.fax = buffer.getString()
	result.email = buffer.getString()
	result.region = buffer.getString()
	return result

def unpackSource(buffer):
	result = Result()
	result.sourceID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.unknown1 = buffer.get('<B')[0]
	result.origin = buffer.getString()
	result.document = buffer.getString()
	result.cote = buffer.getString()
	result.archivage = buffer.getString()
	result.type = buffer.get('<H')[0]
	result.unknown2 = buffer.get('<H')[0]
	result.notes = buffer.getString()
	result.name = buffer.getString()
	return result

def unpackMedia(buffer):
	result = Result()
	result.mediaID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.directory = buffer.getString()
	result.fileName = buffer.getString()
	result.unknown1 = buffer.get('<B')[0]
	result.comment = buffer.getString()
	result.thumbnailLength = buffer.get('<I')[0]
	result.year1 = buffer.get('<B')[0]
	result.year2 = buffer.get('b')[0]
	result.unknown2 = buffer.get('<H')[0]
	result.unknown3 = buffer.get('<H')[0]
	result.thumbnail = buffer.remain()
	return result

def unpackLink(buffer):
	result = Result()
	result.linkID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.fromItemID = buffer.get('<I')[0]
	result.toItemID = buffer.get('<I')[0]
	result.notes = buffer.getString()
	result.unknown1 = buffer.get('<B')[0]
	result.typeIndex = buffer.get('<B')[0]
	return result

def unpackLinkDoc(buffer):
	result = Result()
	result.linkDocID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.evtID = buffer.get('<I')[0]
	result.sourceID = buffer.get('<I')[0]
	result.notes = buffer.getString()
	return result

def unpackLinkMedia(buffer):
	result = Result()
	result.linkMediaID = buffer.get('<I')[0]
	result.creationDate = buffer.get('<I')[0]
	result.modificationDate = buffer.get('<I')[0]
	result.ownerID = buffer.get('<I')[0]
	result.mediaID = buffer.get('<I')[0]
	result.mainMedia = buffer.get('<I')[0]
	return result

def addItemsGenerator(aClass):
	aClass.IndividuGenerator = lambda self: self.itemGenerator('TH5TableIndividus',unpackIndividu)
	aClass.SurnameGenerator = lambda self: self.itemGenerator('TH5TableDicoNoms',unpackSurname)
	aClass.UnionsGenerator = lambda self: self.itemGenerator('TH5TableUnion',unpackUnions)
	aClass.EventsGenerator = lambda self: self.itemGenerator('TH5TableEvenements',unpackEvents)
	aClass.PlaceGenerator = lambda self: self.itemGenerator('TH5TableDicoLieux',unpackPlace)
	aClass.AdresseGenerator = lambda self: self.itemGenerator('TH5TableDicoAdresses',unpackAdresse)
	aClass.SourceGenerator = lambda self: self.itemGenerator('TH5Doc',unpackSource)
	aClass.MediaGenerator = lambda self: self.itemGenerator('TH5TableMedias',unpackMedia)
	aClass.LinkGenerator = lambda self: self.itemGenerator('TBLINK',unpackLink)
	aClass.LinkDocGenerator = lambda self: self.itemGenerator('TH5LinkDoc',unpackLinkDoc)
	aClass.LinkMediaGenerator = lambda self: self.itemGenerator('TBMedia-IdxOwner',unpackLinkMedia)
